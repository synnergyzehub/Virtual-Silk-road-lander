# EmpireOS Starter Kit
This is the GitHub-ready version of your Divine Mechanics OS.
