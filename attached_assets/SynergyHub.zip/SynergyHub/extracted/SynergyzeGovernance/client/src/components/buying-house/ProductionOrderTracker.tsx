import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Loader2, 
  Search, 
  Package, 
  Truck, 
  Factory, 
  ClipboardCheck, 
  ShieldCheck,
  ArrowUpDown,
  FileText,
  Calendar,
  BarChart
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ProductionOrder } from "@shared/schema";

export default function ProductionOrderTracker() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<ProductionOrder | null>(null);

  const { data: orders, isLoading } = useQuery<ProductionOrder[]>({
    queryKey: ["/api/public/production-orders"],
  });

  if (isLoading || !orders) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const filteredOrders = orders.filter(
    (order) =>
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case "pattern":
        return <FileText className="h-5 w-5 mr-2" />;
      case "sampling":
        return <Package className="h-5 w-5 mr-2" />;
      case "bulk_production":
        return <Factory className="h-5 w-5 mr-2" />;
      case "quality_check":
        return <ClipboardCheck className="h-5 w-5 mr-2" />;
      case "ready_for_shipment":
        return <Truck className="h-5 w-5 mr-2" />;
      default:
        return <Package className="h-5 w-5 mr-2" />;
    }
  };

  const getStageBadge = (stage: string) => {
    switch (stage) {
      case "pattern":
        return <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">Pattern</Badge>;
      case "sampling":
        return <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">Sampling</Badge>;
      case "bulk_production":
        return <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">Production</Badge>;
      case "quality_check":
        return <Badge variant="outline" className="bg-indigo-50 text-indigo-800 border-indigo-200">QC</Badge>;
      case "ready_for_shipment":
        return <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">Ready</Badge>;
      default:
        return <Badge variant="outline">{stage}</Badge>;
    }
  };

  const getStageProgress = (stage: string) => {
    switch (stage) {
      case "pattern":
        return 20;
      case "sampling":
        return 40;
      case "bulk_production":
        return 60;
      case "quality_check":
        return 80;
      case "ready_for_shipment":
        return 100;
      default:
        return 0;
    }
  };

  const getDeliveryStatus = (deliveryDate: Date) => {
    const today = new Date();
    const delivery = new Date(deliveryDate);
    
    if (delivery < today) {
      return <Badge variant="destructive">Overdue</Badge>;
    } else {
      const diffTime = Math.abs(delivery.getTime() - today.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 7) {
        return <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">Within 7 days</Badge>;
      } else {
        return <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">On Schedule</Badge>;
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Production Order Tracker</CardTitle>
          <CardDescription>
            Track the status of your production orders and their delivery schedules.
          </CardDescription>
          <div className="pt-4 flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by order number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <ArrowUpDown className="h-4 w-4 mr-2" />
              Sort by Date
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredOrders.length === 0 ? (
            <div className="text-center py-8">
              <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No orders found</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                We couldn't find any production orders matching your search. Try a different search term or check your order number.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order #</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Current Stage</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Delivery Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.orderNumber}</TableCell>
                    <TableCell>{order.quantity} pcs</TableCell>
                    <TableCell>{getStageBadge(order.currentStage)}</TableCell>
                    <TableCell>
                      <Progress value={getStageProgress(order.currentStage)} className="w-[100px]" />
                    </TableCell>
                    <TableCell>
                      {new Date(order.deliveryDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {getDeliveryStatus(order.deliveryDate)}
                    </TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedOrder(order)}
                          >
                            Details
                          </Button>
                        </DialogTrigger>
                        {selectedOrder && (
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Production Order - {selectedOrder.orderNumber}</DialogTitle>
                              <DialogDescription>
                                Detailed information about your production order
                              </DialogDescription>
                            </DialogHeader>
                            
                            <div className="mt-4">
                              <Tabs defaultValue="overview">
                                <TabsList className="grid w-full grid-cols-3">
                                  <TabsTrigger value="overview">Overview</TabsTrigger>
                                  <TabsTrigger value="timeline">Production Timeline</TabsTrigger>
                                  <TabsTrigger value="quality">Quality Reports</TabsTrigger>
                                </TabsList>
                                
                                <TabsContent value="overview" className="space-y-4 mt-4">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Card>
                                      <CardHeader className="py-3">
                                        <CardTitle className="text-base">Order Details</CardTitle>
                                      </CardHeader>
                                      <CardContent className="py-2">
                                        <div className="space-y-2">
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Order Number:</span>
                                            <span className="font-medium">{selectedOrder.orderNumber}</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Quantity:</span>
                                            <span>{selectedOrder.quantity} pcs</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Current Stage:</span>
                                            <span>{getStageBadge(selectedOrder.currentStage)}</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Created On:</span>
                                            <span>{new Date(selectedOrder.createdAt).toLocaleDateString()}</span>
                                          </div>
                                        </div>
                                      </CardContent>
                                    </Card>
                                    
                                    <Card>
                                      <CardHeader className="py-3">
                                        <CardTitle className="text-base">Delivery Information</CardTitle>
                                      </CardHeader>
                                      <CardContent className="py-2">
                                        <div className="space-y-2">
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Delivery Date:</span>
                                            <span className="font-medium">{new Date(selectedOrder.deliveryDate).toLocaleDateString()}</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Status:</span>
                                            <span>{getDeliveryStatus(selectedOrder.deliveryDate)}</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span className="text-sm text-muted-foreground">Days Remaining:</span>
                                            <span>
                                              {Math.max(
                                                0,
                                                Math.ceil(
                                                  (new Date(selectedOrder.deliveryDate).getTime() - new Date().getTime()) / 
                                                  (1000 * 60 * 60 * 24)
                                                )
                                              )} days
                                            </span>
                                          </div>
                                        </div>
                                      </CardContent>
                                    </Card>
                                  </div>
                                  
                                  <Card>
                                    <CardHeader className="py-3">
                                      <CardTitle className="text-base">Production Progress</CardTitle>
                                    </CardHeader>
                                    <CardContent className="py-2">
                                      <div className="space-y-5">
                                        <div>
                                          <div className="flex justify-between mb-2">
                                            <span className="text-sm font-medium">Overall Progress</span>
                                            <span className="text-sm font-medium">{getStageProgress(selectedOrder.currentStage)}%</span>
                                          </div>
                                          <Progress value={getStageProgress(selectedOrder.currentStage)} className="h-2" />
                                        </div>
                                        
                                        <div className="grid grid-cols-5 gap-2">
                                          <div className={`text-center p-2 rounded-md ${selectedOrder.currentStage === "pattern" || selectedOrder.stageUpdates.some(u => u.stage === "pattern") ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                                            <FileText className="h-5 w-5 mx-auto mb-1" />
                                            <span className="text-xs">Pattern</span>
                                          </div>
                                          <div className={`text-center p-2 rounded-md ${selectedOrder.currentStage === "sampling" || selectedOrder.stageUpdates.some(u => u.stage === "sampling") ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                                            <Package className="h-5 w-5 mx-auto mb-1" />
                                            <span className="text-xs">Sampling</span>
                                          </div>
                                          <div className={`text-center p-2 rounded-md ${selectedOrder.currentStage === "bulk_production" || selectedOrder.stageUpdates.some(u => u.stage === "bulk_production") ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                                            <Factory className="h-5 w-5 mx-auto mb-1" />
                                            <span className="text-xs">Production</span>
                                          </div>
                                          <div className={`text-center p-2 rounded-md ${selectedOrder.currentStage === "quality_check" || selectedOrder.stageUpdates.some(u => u.stage === "quality_check") ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                                            <ClipboardCheck className="h-5 w-5 mx-auto mb-1" />
                                            <span className="text-xs">QC</span>
                                          </div>
                                          <div className={`text-center p-2 rounded-md ${selectedOrder.currentStage === "ready_for_shipment" || selectedOrder.stageUpdates.some(u => u.stage === "ready_for_shipment") ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                                            <Truck className="h-5 w-5 mx-auto mb-1" />
                                            <span className="text-xs">Shipping</span>
                                          </div>
                                        </div>
                                      </div>
                                    </CardContent>
                                  </Card>
                                </TabsContent>
                                
                                <TabsContent value="timeline" className="mt-4">
                                  <Card>
                                    <CardHeader className="py-3">
                                      <CardTitle className="text-base">Production Timeline</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                      <div className="space-y-4">
                                        {selectedOrder.stageUpdates.map((update, index) => (
                                          <div key={index} className="flex">
                                            <div className="flex flex-col items-center mr-4">
                                              <div className="rounded-full bg-primary w-8 h-8 flex items-center justify-center text-primary-foreground">
                                                {getStageIcon(update.stage)}
                                              </div>
                                              {index < selectedOrder.stageUpdates.length - 1 && (
                                                <div className="w-0.5 h-12 bg-primary mt-2"></div>
                                              )}
                                            </div>
                                            <div className="pb-6">
                                              <h4 className="text-base font-medium capitalize">
                                                {update.stage.replace("_", " ")} Stage
                                              </h4>
                                              <p className="text-sm text-muted-foreground">
                                                {new Date(update.date).toLocaleDateString()}
                                              </p>
                                              <p className="text-sm mt-1">
                                                {update.stage === "pattern" && "Pattern making and design finalization completed"}
                                                {update.stage === "sampling" && "Sample production and approval process completed"}
                                                {update.stage === "bulk_production" && "Bulk production started for your order"}
                                                {update.stage === "quality_check" && "Quality control checks initiated for produced goods"}
                                                {update.stage === "ready_for_shipment" && "Order ready for shipment and awaiting dispatch"}
                                              </p>
                                            </div>
                                          </div>
                                        ))}
                                        
                                        {selectedOrder.currentStage !== "ready_for_shipment" && (
                                          <div className="flex">
                                            <div className="flex flex-col items-center mr-4">
                                              <div className="rounded-full border-2 border-dashed border-muted-foreground w-8 h-8 flex items-center justify-center text-muted-foreground">
                                                <Calendar className="h-4 w-4" />
                                              </div>
                                            </div>
                                            <div>
                                              <h4 className="text-base font-medium text-muted-foreground">
                                                Estimated Delivery
                                              </h4>
                                              <p className="text-sm text-muted-foreground">
                                                {new Date(selectedOrder.deliveryDate).toLocaleDateString()}
                                              </p>
                                              <p className="text-sm mt-1">
                                                Expected completion and shipping date
                                              </p>
                                            </div>
                                          </div>
                                        )}
                                      </div>
                                    </CardContent>
                                  </Card>
                                </TabsContent>
                                
                                <TabsContent value="quality" className="mt-4">
                                  <Card>
                                    <CardHeader className="py-3">
                                      <div className="flex justify-between items-center">
                                        <CardTitle className="text-base">Quality Control Reports</CardTitle>
                                        <Badge variant="outline" className="flex items-center">
                                          <ShieldCheck className="h-3 w-3 mr-1" />
                                          QC Standards
                                        </Badge>
                                      </div>
                                    </CardHeader>
                                    <CardContent>
                                      {!selectedOrder.qualityReports || selectedOrder.currentStage === "pattern" || selectedOrder.currentStage === "sampling" ? (
                                        <div className="text-center py-6">
                                          <ClipboardCheck className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
                                          <h3 className="text-base font-medium mb-2">Quality reports not available yet</h3>
                                          <p className="text-sm text-muted-foreground max-w-md mx-auto">
                                            Quality control reports will be available once your order reaches the quality check stage.
                                          </p>
                                        </div>
                                      ) : (
                                        <div className="space-y-4">
                                          <div className="flex items-center justify-center space-x-4">
                                            <div className="text-center">
                                              <BarChart className="h-5 w-5 mx-auto mb-1 text-green-500" />
                                              <span className="text-sm font-medium">Overall Score</span>
                                              <span className="block text-2xl font-bold">4.8/5</span>
                                            </div>
                                          </div>
                                          
                                          <Table>
                                            <TableHeader>
                                              <TableRow>
                                                <TableHead>Criteria</TableHead>
                                                <TableHead>Result</TableHead>
                                                <TableHead>Status</TableHead>
                                              </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                              <TableRow>
                                                <TableCell>Material Quality</TableCell>
                                                <TableCell>
                                                  <Progress value={95} className="w-[100px]" />
                                                </TableCell>
                                                <TableCell>
                                                  <Badge className="bg-green-500">Passed</Badge>
                                                </TableCell>
                                              </TableRow>
                                              <TableRow>
                                                <TableCell>Stitching Consistency</TableCell>
                                                <TableCell>
                                                  <Progress value={90} className="w-[100px]" />
                                                </TableCell>
                                                <TableCell>
                                                  <Badge className="bg-green-500">Passed</Badge>
                                                </TableCell>
                                              </TableRow>
                                              <TableRow>
                                                <TableCell>Color Consistency</TableCell>
                                                <TableCell>
                                                  <Progress value={98} className="w-[100px]" />
                                                </TableCell>
                                                <TableCell>
                                                  <Badge className="bg-green-500">Passed</Badge>
                                                </TableCell>
                                              </TableRow>
                                              <TableRow>
                                                <TableCell>Size Accuracy</TableCell>
                                                <TableCell>
                                                  <Progress value={92} className="w-[100px]" />
                                                </TableCell>
                                                <TableCell>
                                                  <Badge className="bg-green-500">Passed</Badge>
                                                </TableCell>
                                              </TableRow>
                                            </TableBody>
                                          </Table>
                                        </div>
                                      )}
                                    </CardContent>
                                  </Card>
                                </TabsContent>
                              </Tabs>
                            </div>
                          </DialogContent>
                        )}
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}