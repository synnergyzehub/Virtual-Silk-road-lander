import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { ProductionOrder } from "@shared/schema";
import { Loader2 } from "lucide-react";

const stageOrder = {
  pattern: 0,
  sampling: 1,
  bulk_production: 2,
  quality_check: 3,
  ready_for_shipment: 4,
};

export function ProductionMonitor() {
  const { data: orders, isLoading } = useQuery<ProductionOrder[]>({
    queryKey: ["/api/production-orders"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Production Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {orders?.map((order) => (
            <div key={order.id} className="space-y-2">
              <div className="flex justify-between">
                <div>
                  <p className="font-medium">Order #{order.orderNumber}</p>
                  <p className="text-sm text-muted-foreground">
                    Delivery: {new Date(order.deliveryDate).toLocaleDateString()}
                  </p>
                </div>
                <Badge>{order.currentStage.replace('_', ' ')}</Badge>
              </div>
              <Progress
                value={((stageOrder[order.currentStage] + 1) / 5) * 100}
                className="h-2"
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
