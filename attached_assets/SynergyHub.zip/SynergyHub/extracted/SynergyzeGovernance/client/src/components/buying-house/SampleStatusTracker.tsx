import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2, FileSearch, MessageCircle, FileText } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Sample } from "@shared/schema";

export default function SampleStatusTracker() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSample, setSelectedSample] = useState<Sample | null>(null);

  const { data: samples, isLoading } = useQuery<Sample[]>({
    queryKey: ["/api/public/samples"],
  });

  if (isLoading || !samples) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const filteredSamples = samples.filter(
    (sample) =>
      sample.sampleNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sample.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800 border-green-300";
      case "rejected":
        return "bg-red-100 text-red-800 border-red-300";
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "in_development":
        return "bg-blue-100 text-blue-800 border-blue-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-500">Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "pending":
        return <Badge variant="outline">Pending</Badge>;
      case "in_development":
        return <Badge className="bg-blue-500">In Development</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getSampleProgress = (status: string) => {
    switch (status) {
      case "approved":
        return 100;
      case "rejected":
        return 100;
      case "in_development":
        return 66;
      case "pending":
        return 33;
      default:
        return 0;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Sample Status Tracker</CardTitle>
          <CardDescription>
            Track the status of your sample requests. Enter your sample number or name to search.
          </CardDescription>
          <div className="pt-4">
            <Input
              placeholder="Search by sample number or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-md"
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredSamples.length === 0 ? (
            <div className="text-center py-8">
              <FileSearch className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No samples found</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                We couldn't find any samples matching your search. Try a different search term or check your sample number.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sample #</TableHead>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSamples.map((sample) => (
                  <TableRow key={sample.id}>
                    <TableCell className="font-medium">{sample.sampleNumber}</TableCell>
                    <TableCell>{sample.productName}</TableCell>
                    <TableCell>{sample.category}</TableCell>
                    <TableCell>{getStatusBadge(sample.status)}</TableCell>
                    <TableCell>
                      <Progress value={getSampleProgress(sample.status)} className="w-[100px]" />
                    </TableCell>
                    <TableCell>
                      {new Date(sample.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedSample(sample)}
                          >
                            Details
                          </Button>
                        </DialogTrigger>
                        {selectedSample && (
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Sample Details - {selectedSample.sampleNumber}</DialogTitle>
                              <DialogDescription>
                                Detailed information about your sample request
                              </DialogDescription>
                            </DialogHeader>
                            
                            <div className="mt-4">
                              <Tabs defaultValue="details">
                                <TabsList className="grid w-full grid-cols-3">
                                  <TabsTrigger value="details">Details</TabsTrigger>
                                  <TabsTrigger value="timeline">Timeline</TabsTrigger>
                                  <TabsTrigger value="comments">Comments</TabsTrigger>
                                </TabsList>
                                
                                <TabsContent value="details" className="space-y-4 mt-4">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Product Name</h4>
                                      <p className="text-base">{selectedSample.productName}</p>
                                    </div>
                                    <div>
                                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Category</h4>
                                      <p className="text-base">{selectedSample.category}</p>
                                    </div>
                                    <div>
                                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Status</h4>
                                      <div>{getStatusBadge(selectedSample.status)}</div>
                                    </div>
                                    <div>
                                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Created On</h4>
                                      <p className="text-base">{new Date(selectedSample.createdAt).toLocaleDateString()}</p>
                                    </div>
                                  </div>
                                  
                                  <div className="pt-2">
                                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Specifications</h4>
                                    <div className="bg-muted p-3 rounded-md">
                                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                        {Object.entries(selectedSample.specifications).map(([key, value]) => (
                                          <li key={key} className="flex">
                                            <span className="text-sm font-medium w-20">{key}:</span>
                                            <span className="text-sm">{value}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  </div>
                                  
                                  {selectedSample.developmentNotes && (
                                    <div className="pt-2">
                                      <h4 className="text-sm font-medium text-muted-foreground mb-2">Development Notes</h4>
                                      <div className="bg-muted p-3 rounded-md">
                                        <p className="text-sm">{selectedSample.developmentNotes}</p>
                                      </div>
                                    </div>
                                  )}
                                </TabsContent>
                                
                                <TabsContent value="timeline" className="space-y-4 mt-4">
                                  <div className="space-y-4">
                                    <div className="flex">
                                      <div className="flex flex-col items-center mr-4">
                                        <div className="rounded-full bg-primary w-8 h-8 flex items-center justify-center text-primary-foreground">1</div>
                                        <div className="w-0.5 h-full bg-primary mt-2"></div>
                                      </div>
                                      <div className="pb-6">
                                        <h4 className="text-base font-medium">Sample Request Created</h4>
                                        <p className="text-sm text-muted-foreground">{new Date(selectedSample.createdAt).toLocaleString()}</p>
                                        <p className="text-sm mt-1">Sample request submitted for {selectedSample.productName}</p>
                                      </div>
                                    </div>
                                    
                                    {(selectedSample.status === "in_development" || selectedSample.status === "approved" || selectedSample.status === "rejected") && (
                                      <div className="flex">
                                        <div className="flex flex-col items-center mr-4">
                                          <div className="rounded-full bg-primary w-8 h-8 flex items-center justify-center text-primary-foreground">2</div>
                                          {(selectedSample.status === "approved" || selectedSample.status === "rejected") && (
                                            <div className="w-0.5 h-full bg-primary mt-2"></div>
                                          )}
                                        </div>
                                        <div className="pb-6">
                                          <h4 className="text-base font-medium">Sample Development Started</h4>
                                          <p className="text-sm text-muted-foreground">{new Date(selectedSample.updatedAt).toLocaleString()}</p>
                                          <p className="text-sm mt-1">Our production team has started working on your sample</p>
                                        </div>
                                      </div>
                                    )}
                                    
                                    {(selectedSample.status === "approved" || selectedSample.status === "rejected") && (
                                      <div className="flex">
                                        <div className="flex flex-col items-center mr-4">
                                          <div className={`rounded-full w-8 h-8 flex items-center justify-center text-primary-foreground ${selectedSample.status === "approved" ? "bg-green-500" : "bg-red-500"}`}>3</div>
                                        </div>
                                        <div>
                                          <h4 className="text-base font-medium">
                                            Sample {selectedSample.status === "approved" ? "Approved" : "Rejected"}
                                          </h4>
                                          <p className="text-sm text-muted-foreground">{new Date(selectedSample.updatedAt).toLocaleString()}</p>
                                          <p className="text-sm mt-1">
                                            {selectedSample.status === "approved"
                                              ? "Your sample has been approved and is ready for production"
                                              : "Your sample was rejected. Please check the comments for details"}
                                          </p>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </TabsContent>
                                
                                <TabsContent value="comments" className="mt-4">
                                  <div className="bg-muted rounded-md p-4">
                                    <div className="flex items-center mb-4">
                                      <MessageCircle className="h-5 w-5 mr-2" />
                                      <h4 className="text-base font-medium">Communication</h4>
                                    </div>
                                    
                                    <div className="space-y-4">
                                      <div className="bg-card p-3 rounded-md border">
                                        <div className="flex justify-between items-start mb-2">
                                          <span className="font-medium">System Notification</span>
                                          <span className="text-xs text-muted-foreground">{new Date(selectedSample.createdAt).toLocaleString()}</span>
                                        </div>
                                        <p className="text-sm">Your sample request has been received and is currently under review.</p>
                                      </div>
                                      
                                      {selectedSample.status !== "pending" && (
                                        <div className="bg-card p-3 rounded-md border">
                                          <div className="flex justify-between items-start mb-2">
                                            <span className="font-medium">Production Team</span>
                                            <span className="text-xs text-muted-foreground">{new Date(selectedSample.updatedAt).toLocaleString()}</span>
                                          </div>
                                          <p className="text-sm">
                                            {selectedSample.status === "in_development"
                                              ? "We are currently working on your sample. We'll update you once it's ready for review."
                                              : selectedSample.status === "approved"
                                              ? "Your sample has been approved. You can now proceed with production orders."
                                              : "We regret to inform you that your sample could not be approved due to technical limitations."}
                                          </p>
                                        </div>
                                      )}
                                    </div>
                                    
                                    <div className="mt-4">
                                      <Input placeholder="Type your message here..." disabled />
                                      <p className="text-xs text-muted-foreground mt-2">
                                        Please login to your account to send messages
                                      </p>
                                    </div>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            </div>
                            
                            <DialogFooter>
                              {selectedSample.status === "approved" && (
                                <Button>
                                  <FileText className="h-4 w-4 mr-2" />
                                  Place Production Order
                                </Button>
                              )}
                            </DialogFooter>
                          </DialogContent>
                        )}
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}