import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Loader2, Search, ShoppingCart, Star, Heart, ExternalLink } from "lucide-react";
import { Dispatch, SetStateAction } from "react";

type Product = {
  id: number;
  name: string;
  category: string;
  image?: string;
  description: string;
  minOrderQuantity: number;
  price: { 
    min: number; 
    max: number; 
    currency: string 
  };
  availableColors: string[];
  inStock: boolean;
  rating?: {
    average: number;
    count: number;
  };
  leadTime?: string;
  featured?: boolean;
};

interface MarketplaceProductGridProps {
  category: string;
  priceRange: [number, number];
  inStockOnly: boolean;
  searchQuery: string;
  setSearchQuery: Dispatch<SetStateAction<string>>;
  sortBy: string;
  setSortBy: Dispatch<SetStateAction<string>>;
}

export default function MarketplaceProductGrid({
  category,
  priceRange,
  inStockOnly,
  searchQuery,
  setSearchQuery,
  sortBy,
  setSortBy,
}: MarketplaceProductGridProps) {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/public/marketplace/products"],
  });

  if (isLoading || !products) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const filteredProducts = products
    .filter(
      (product) =>
        (category === "all" || product.category === category) &&
        (product.price.min >= priceRange[0] && product.price.min <= priceRange[1]) &&
        (!inStockOnly || product.inStock) &&
        (searchQuery === "" ||
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortBy === "price-low") {
        return a.price.min - b.price.min;
      } else if (sortBy === "price-high") {
        return b.price.min - a.price.min;
      } else if (sortBy === "rating") {
        return (b.rating?.average || 0) - (a.rating?.average || 0);
      }
      // Default: popularity (using id as proxy since we don't have real data)
      return a.id - b.id;
    });

  return (
    <Card>
      <CardHeader className="pb-0">
        <div className="flex flex-col md:flex-row justify-between gap-4 items-start md:items-center">
          <div className="w-full md:w-1/2 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products, materials, manufacturers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground whitespace-nowrap">Sort by:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Popularity</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground">No products found matching your criteria.</p>
            <Button variant="outline" className="mt-4" onClick={() => setSearchQuery("")}>
              Clear search
            </Button>
          </div>
        ) : (
          <>
            <p className="mb-4 text-sm text-muted-foreground">
              Showing {filteredProducts.length} result{filteredProducts.length !== 1 ? 's' : ''}
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div 
                  key={product.id} 
                  className="group border rounded-lg overflow-hidden hover:shadow-md transition-all"
                >
                  <div className="relative aspect-[4/3] bg-muted">
                    {product.image ? (
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="object-cover w-full h-full" 
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full w-full bg-secondary/20">
                        <span className="text-muted-foreground">No image</span>
                      </div>
                    )}
                    
                    {!product.inStock && (
                      <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                        <Badge variant="destructive" className="text-base font-medium">
                          Out of Stock
                        </Badge>
                      </div>
                    )}
                    
                    {product.featured && (
                      <div className="absolute top-2 left-2">
                        <Badge className="bg-amber-500 text-white">Featured</Badge>
                      </div>
                    )}
                    
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/70 hover:bg-white text-muted-foreground hover:text-rose-500"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium mb-1 group-hover:text-primary transition-colors">
                          {product.name}
                        </h3>
                        <Badge variant="outline" className="mb-2">{product.category}</Badge>
                      </div>
                      
                      {product.rating && (
                        <div className="flex items-center text-amber-500">
                          <Star className="fill-current h-4 w-4 mr-1" />
                          <span className="text-sm font-medium">{product.rating.average}</span>
                        </div>
                      )}
                    </div>
                    
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                      {product.description}
                    </p>
                    
                    <div className="mt-auto space-y-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <span className="text-sm text-muted-foreground">Price</span>
                          <p className="font-medium">
                            {product.price.currency} {product.price.min} - {product.price.max}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="text-sm text-muted-foreground">MOQ</span>
                          <p className="text-sm">{product.minOrderQuantity} pcs</p>
                        </div>
                      </div>
                      
                      {product.leadTime && (
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span>Lead time: {product.leadTime}</span>
                        </div>
                      )}
                      
                      <div className="flex gap-2 pt-2">
                        <Button variant="outline" className="flex-1" size="sm">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Details
                        </Button>
                        <Button className="flex-1" size="sm" disabled={!product.inStock}>
                          <ShoppingCart className="h-3 w-3 mr-1" />
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}