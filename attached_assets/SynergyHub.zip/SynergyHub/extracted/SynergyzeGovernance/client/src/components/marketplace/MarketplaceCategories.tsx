import { Dispatch, SetStateAction } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Grid2X2, Scissors, Shirt, Package, ShoppingBag } from "lucide-react";

interface MarketplaceCategoriesProps {
  activeCategory: string;
  setActiveCategory: Dispatch<SetStateAction<string>>;
}

export default function MarketplaceCategories({
  activeCategory,
  setActiveCategory,
}: MarketplaceCategoriesProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
          <Button
            variant={activeCategory === "all" ? "default" : "outline"}
            className="flex flex-col h-auto py-4 px-1"
            onClick={() => setActiveCategory("all")}
          >
            <Grid2X2 className="h-5 w-5 mb-2" />
            <span className="text-xs">All Products</span>
          </Button>
          
          <Button
            variant={activeCategory === "Apparel" ? "default" : "outline"}
            className="flex flex-col h-auto py-4 px-1"
            onClick={() => setActiveCategory("Apparel")}
          >
            <Shirt className="h-5 w-5 mb-2" />
            <span className="text-xs">Apparel</span>
          </Button>
          
          <Button
            variant={activeCategory === "Fabric" ? "default" : "outline"}
            className="flex flex-col h-auto py-4 px-1"
            onClick={() => setActiveCategory("Fabric")}
          >
            <Scissors className="h-5 w-5 mb-2" />
            <span className="text-xs">Fabric</span>
          </Button>
          
          <Button
            variant={activeCategory === "Accessories" ? "default" : "outline"}
            className="flex flex-col h-auto py-4 px-1"
            onClick={() => setActiveCategory("Accessories")}
          >
            <ShoppingBag className="h-5 w-5 mb-2" />
            <span className="text-xs">Accessories</span>
          </Button>
          
          <Button
            variant={activeCategory === "Packaging" ? "default" : "outline"}
            className="flex flex-col h-auto py-4 px-1"
            onClick={() => setActiveCategory("Packaging")}
          >
            <Package className="h-5 w-5 mb-2" />
            <span className="text-xs">Packaging</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}