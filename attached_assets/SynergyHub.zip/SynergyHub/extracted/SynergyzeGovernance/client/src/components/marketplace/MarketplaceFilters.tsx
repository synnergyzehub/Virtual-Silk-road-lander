import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Filter, RefreshCw } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Dispatch, SetStateAction } from "react";

interface MarketplaceFiltersProps {
  priceRange: [number, number];
  setPriceRange: Dispatch<SetStateAction<[number, number]>>;
  inStockOnly: boolean;
  setInStockOnly: Dispatch<SetStateAction<boolean>>;
  activeCategory: string;
  setActiveCategory: Dispatch<SetStateAction<string>>;
}

export default function MarketplaceFilters({
  priceRange,
  setPriceRange,
  inStockOnly,
  setInStockOnly,
  activeCategory,
  setActiveCategory,
}: MarketplaceFiltersProps) {
  const handleResetFilters = () => {
    setPriceRange([0, 1000]);
    setInStockOnly(false);
    setActiveCategory("all");
  };

  return (
    <Card className="sticky top-4">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={handleResetFilters}>
            <RefreshCw className="h-3 w-3 mr-1" />
            Reset
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-4">
          <div>
            <Label htmlFor="price-filter" className="text-base">
              Price Range (USD)
            </Label>
            <div className="pt-4 px-2">
              <Slider
                id="price-filter"
                defaultValue={[0, 1000]}
                max={1000}
                step={10}
                value={priceRange}
                onValueChange={(value) => setPriceRange(value as [number, number])}
              />
            </div>
            <div className="flex items-center justify-between mt-2 text-sm">
              <span>${priceRange[0]}</span>
              <span>${priceRange[1]}</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="in-stock" className="text-base">
              Availability
            </Label>
            <div className="flex items-center space-x-2 pt-1">
              <Switch
                id="in-stock"
                checked={inStockOnly}
                onCheckedChange={setInStockOnly}
              />
              <Label htmlFor="in-stock" className="text-sm">
                In stock only
              </Label>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="product-type">
              <AccordionTrigger className="text-base">Product Type</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="type-all"
                      name="product-type"
                      className="rounded-full"
                      checked={activeCategory === "all"}
                      onChange={() => setActiveCategory("all")}
                    />
                    <Label htmlFor="type-all" className="text-sm cursor-pointer">
                      All Products
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="type-apparel"
                      name="product-type"
                      className="rounded-full"
                      checked={activeCategory === "Apparel"}
                      onChange={() => setActiveCategory("Apparel")}
                    />
                    <Label htmlFor="type-apparel" className="text-sm cursor-pointer">
                      Apparel
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="type-fabric"
                      name="product-type"
                      className="rounded-full"
                      checked={activeCategory === "Fabric"}
                      onChange={() => setActiveCategory("Fabric")}
                    />
                    <Label htmlFor="type-fabric" className="text-sm cursor-pointer">
                      Fabric
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="type-accessories"
                      name="product-type"
                      className="rounded-full"
                      checked={activeCategory === "Accessories"}
                      onChange={() => setActiveCategory("Accessories")}
                    />
                    <Label htmlFor="type-accessories" className="text-sm cursor-pointer">
                      Accessories
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="type-packaging"
                      name="product-type"
                      className="rounded-full"
                      checked={activeCategory === "Packaging"}
                      onChange={() => setActiveCategory("Packaging")}
                    />
                    <Label htmlFor="type-packaging" className="text-sm cursor-pointer">
                      Packaging
                    </Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="material">
              <AccordionTrigger className="text-base">Material</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="material-cotton" className="rounded" />
                    <Label htmlFor="material-cotton" className="text-sm cursor-pointer">
                      Cotton
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="material-polyester" className="rounded" />
                    <Label htmlFor="material-polyester" className="text-sm cursor-pointer">
                      Polyester
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="material-linen" className="rounded" />
                    <Label htmlFor="material-linen" className="text-sm cursor-pointer">
                      Linen
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="material-wool" className="rounded" />
                    <Label htmlFor="material-wool" className="text-sm cursor-pointer">
                      Wool
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="material-silk" className="rounded" />
                    <Label htmlFor="material-silk" className="text-sm cursor-pointer">
                      Silk
                    </Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="minimum-order">
              <AccordionTrigger className="text-base">Minimum Order</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="moq-50" className="rounded" />
                    <Label htmlFor="moq-50" className="text-sm cursor-pointer">
                      Under 50 pcs
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="moq-100" className="rounded" />
                    <Label htmlFor="moq-100" className="text-sm cursor-pointer">
                      50 - 100 pcs
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="moq-300" className="rounded" />
                    <Label htmlFor="moq-300" className="text-sm cursor-pointer">
                      100 - 300 pcs
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="moq-500" className="rounded" />
                    <Label htmlFor="moq-500" className="text-sm cursor-pointer">
                      300 - 500 pcs
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="moq-over" className="rounded" />
                    <Label htmlFor="moq-over" className="text-sm cursor-pointer">
                      Over 500 pcs
                    </Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="lead-time">
              <AccordionTrigger className="text-base">Lead Time</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="lead-7" className="rounded" />
                    <Label htmlFor="lead-7" className="text-sm cursor-pointer">
                      Under 7 days
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="lead-14" className="rounded" />
                    <Label htmlFor="lead-14" className="text-sm cursor-pointer">
                      7-14 days
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="lead-30" className="rounded" />
                    <Label htmlFor="lead-30" className="text-sm cursor-pointer">
                      15-30 days
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="lead-60" className="rounded" />
                    <Label htmlFor="lead-60" className="text-sm cursor-pointer">
                      30-60 days
                    </Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        <div className="pt-4">
          <Button className="w-full">Apply Filters</Button>
        </div>
      </CardContent>
    </Card>
  );
}