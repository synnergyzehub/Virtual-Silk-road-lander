import { useAuth } from "@/hooks/use-auth";
import { HeaderNav } from "@/components/dashboard/HeaderNav";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { WovenSupplyView } from "@/components/dashboard/WovenSupplyView";
import { CommuneConnectView } from "@/components/dashboard/CommuneConnectView";
import { SynergyzeView } from "@/components/dashboard/SynergyzeView";
import { useState } from "react";

type DashboardView = "woven" | "commune" | "synergyze";

export default function DashboardPage() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState<DashboardView>("woven");

  return (
    <div className="min-h-screen bg-background">
      <HeaderNav />
      <div className="flex">
        <Sidebar currentView={currentView} onViewChange={setCurrentView} />
        <main className="flex-1 p-6">
          {currentView === "woven" && <WovenSupplyView />}
          {currentView === "commune" && <CommuneConnectView />}
          {currentView === "synergyze" && <SynergyzeView />}
        </main>
      </div>
    </div>
  );
}
