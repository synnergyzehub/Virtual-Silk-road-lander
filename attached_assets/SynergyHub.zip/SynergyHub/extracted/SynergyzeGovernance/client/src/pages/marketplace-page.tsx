import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import MarketplaceProductGrid from "@/components/marketplace/MarketplaceProductGrid";
import MarketplaceFilters from "@/components/marketplace/MarketplaceFilters";
import MarketplaceFeatured from "@/components/marketplace/MarketplaceFeatured";
import MarketplaceCategories from "@/components/marketplace/MarketplaceCategories";
import { ChevronLeft, Home, Package, ShoppingCart, User } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

export default function MarketplacePage() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("popularity");

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto py-4 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8" />
              <span className="text-xl font-bold">Woven Supply</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full text-xs w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/auth">Login / Register</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>My Orders</DropdownMenuItem>
                  <DropdownMenuItem>Saved Items</DropdownMenuItem>
                  <DropdownMenuItem>My Account</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="outline" asChild>
                <Link href="/buying-house">Buying House</Link>
              </Button>
              <Button asChild>
                <Link href="/">Dashboard</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      <div className="container mx-auto py-6 px-4">
        <div className="flex items-center mb-6 text-sm">
          <Link href="/">
            <a className="flex items-center text-muted-foreground hover:text-foreground">
              <Home className="h-4 w-4 mr-1" />
              Home
            </a>
          </Link>
          <ChevronLeft className="h-4 w-4 mx-2 rotate-90 text-muted-foreground" />
          <span>Marketplace</span>
        </div>
        
        <h1 className="text-3xl font-bold mb-6">Textile Marketplace</h1>
        
        <MarketplaceCategories 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory}
        />
        
        <div className="mt-8">
          <MarketplaceFeatured />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <div className="md:col-span-1">
            <MarketplaceFilters 
              priceRange={priceRange}
              setPriceRange={setPriceRange}
              inStockOnly={inStockOnly}
              setInStockOnly={setInStockOnly}
              activeCategory={activeCategory}
              setActiveCategory={setActiveCategory}
            />
          </div>
          
          <div className="md:col-span-3">
            <MarketplaceProductGrid 
              category={activeCategory}
              priceRange={priceRange}
              inStockOnly={inStockOnly}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              sortBy={sortBy}
              setSortBy={setSortBy}
            />
          </div>
        </div>
      </div>
      
      <footer className="bg-muted py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-medium text-lg mb-4">About Woven Supply</h3>
              <p className="text-muted-foreground text-sm">
                Connecting textile manufacturers, suppliers, and buyers in a seamless marketplace experience.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/buying-house">Buying House</Link></li>
                <li><Link href="/marketplace">Marketplace</Link></li>
                <li><a href="#">Become a Vendor</a></li>
                <li><a href="#">Help Center</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-4">Contact</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Email: info@wovensupply.com</li>
                <li>Phone: +1 (123) 456-7890</li>
                <li>Address: 123 Textile Row, Fabric City</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-4">Subscribe</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Stay updated with the latest products and offers.
              </p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="flex h-10 w-full rounded-l-md border border-input bg-background px-3 py-2 text-sm"
                />
                <Button className="rounded-l-none">Subscribe</Button>
              </div>
            </div>
          </div>
          
          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Woven Supply. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}