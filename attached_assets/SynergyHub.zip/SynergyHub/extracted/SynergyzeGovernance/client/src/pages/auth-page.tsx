import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, type InsertUser } from "@shared/schema";
import { Redirect, Link } from "wouter";
import { Loader2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();

  const loginForm = useForm<Pick<InsertUser, "username" | "password">>({
    resolver: zodResolver(insertUserSchema.pick({ username: true, password: true })),
  });

  const registerForm = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      gdprConsent: false,
    },
  });

  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      <div className="flex flex-col items-center justify-center p-8">
        <div className="w-full max-w-md space-y-8">
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-6">Login</h2>
            <form
              onSubmit={loginForm.handleSubmit((data) =>
                loginMutation.mutate(data)
              )}
              className="space-y-4"
            >
              <div>
                <Input
                  placeholder="Username"
                  {...loginForm.register("username")}
                />
                {loginForm.formState.errors.username?.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {loginForm.formState.errors.username.message}
                  </p>
                )}
              </div>
              <div>
                <Input
                  type="password"
                  placeholder="Password"
                  {...loginForm.register("password")}
                />
                {loginForm.formState.errors.password?.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {loginForm.formState.errors.password.message}
                  </p>
                )}
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Login"
                )}
              </Button>
            </form>
          </Card>

          <Card className="p-6 mt-6">
            <h2 className="text-2xl font-bold mb-6">Register</h2>
            <form
              onSubmit={registerForm.handleSubmit((data) =>
                registerMutation.mutate(data)
              )}
              className="space-y-4"
            >
              <div>
                <Input
                  placeholder="Username"
                  {...registerForm.register("username")}
                />
                {registerForm.formState.errors.username?.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {registerForm.formState.errors.username.message}
                  </p>
                )}
              </div>
              <div>
                <Input
                  type="password"
                  placeholder="Password"
                  {...registerForm.register("password")}
                />
                {registerForm.formState.errors.password?.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {registerForm.formState.errors.password.message}
                  </p>
                )}
              </div>
              <div>
                <select
                  {...registerForm.register("role")}
                  className="w-full p-2 border rounded"
                >
                  <option value="admin">Admin</option>
                  <option value="supply_chain_manager">Supply Chain Manager</option>
                  <option value="retail_manager">Retail Manager</option>
                  <option value="finance_specialist">Finance Specialist</option>
                </select>
                {registerForm.formState.errors.role?.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {registerForm.formState.errors.role.message}
                  </p>
                )}
              </div>
              <div className="space-y-4">
                <Card className="p-4">
                  <CardHeader className="p-0">
                    <CardTitle className="text-sm font-medium">Data Privacy Consent</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0 pt-4">
                    <p className="text-sm text-muted-foreground mb-4">
                      We collect and process your data to provide our services. Please review our privacy policy and indicate your consent.
                    </p>
                    <div className="space-y-4">
                      <div className="flex items-start space-x-2">
                        <Checkbox
                          id="terms"
                          checked={registerForm.watch("gdprConsent")}
                          onCheckedChange={(checked) => {
                            registerForm.setValue("gdprConsent", checked === true);
                          }}
                        />
                        <div className="grid gap-1.5 leading-none">
                          <label
                            htmlFor="terms"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Accept Terms and Privacy Policy
                          </label>
                          <p className="text-sm text-muted-foreground">
                            I have read and agree to the{" "}
                            <Link href="/privacy-policy" className="underline">
                              privacy policy
                            </Link>
                            .
                          </p>
                        </div>
                      </div>
                      {registerForm.formState.errors.gdprConsent?.message && (
                        <p className="text-red-500 text-sm">
                          {registerForm.formState.errors.gdprConsent.message}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Register"
                )}
              </Button>
            </form>
          </Card>
        </div>
      </div>

      <div className="hidden md:flex flex-col items-center justify-center p-8 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
        <div className="max-w-md">
          <h1 className="text-4xl font-bold mb-4">
            Supply Chain Management Dashboard
          </h1>
          <p className="text-lg mb-6">
            Seamlessly manage your entire supply chain with our integrated
            platform. Connect vendors, track inventory, and monitor financial
            transactions all in one place.
          </p>
          <ul className="space-y-4">
            <li className="flex items-center">
              ✓ End-to-end supply chain visibility
            </li>
            <li className="flex items-center">
              ✓ Real-time financial tracking
            </li>
            <li className="flex items-center">
              ✓ Automated inventory management
            </li>
            <li className="flex items-center">
              ✓ Comprehensive reporting
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}