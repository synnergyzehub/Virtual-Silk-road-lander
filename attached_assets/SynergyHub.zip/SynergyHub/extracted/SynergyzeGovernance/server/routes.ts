import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { requirePermission, auditLog, errorHandler } from "./middleware";
import { Request } from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Woven Supply endpoints
  app.get("/api/dashboard/summary", requirePermission("inventory.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const summary = {
      purchaseOrders: 124,
      pendingDeliveries: 45,
      activeVendors: 23,
      totalInventory: 5678
    };

    await auditLog(req, 'view_summary', 'dashboard', 'summary');
    res.json(summary);
  });

  app.get("/api/dashboard/inventory", requirePermission("inventory.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const inventory = {
      categories: ["Raw Materials", "WIP", "Finished Goods", "Packaging"],
      data: [2500, 1200, 1800, 178]
    };

    await auditLog(req, 'view_inventory', 'dashboard', 'inventory');
    res.json(inventory);
  });

  // Commune Connect endpoints
  app.get("/api/retail/summary", requirePermission("orders.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const summary = {
      totalOrders: 856,
      pendingOrders: 42,
      totalStores: 15,
      revenue: 2450000
    };

    await auditLog(req, 'view_retail_summary', 'retail', 'summary');
    res.json(summary);
  });

  app.get("/api/retail/trends", requirePermission("orders.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const trends = [
      { date: "2024-03-01", orders: 42, revenue: 210000 },
      { date: "2024-03-02", orders: 38, revenue: 190000 },
      { date: "2024-03-03", orders: 45, revenue: 225000 },
      { date: "2024-03-04", orders: 37, revenue: 185000 },
      { date: "2024-03-05", orders: 41, revenue: 205000 }
    ];

    await auditLog(req, 'view_retail_trends', 'retail', 'trends');
    res.json(trends);
  });

  // Buying House endpoints
  app.get("/api/samples", requirePermission("inventory.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    // Mock data for samples
    const samples = [
      {
        id: 1,
        sampleNumber: "SAM001",
        productName: "Cotton T-Shirt",
        status: "approved",
        buyerId: 1,
        category: "Apparel",
        specifications: { size: "M", color: "Blue", fabric: "100% Cotton" },
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        sampleNumber: "SAM002",
        productName: "Denim Jeans",
        status: "in_development",
        buyerId: 2,
        category: "Apparel",
        specifications: { size: "32", style: "Slim Fit", fabric: "Denim" },
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    await auditLog(req, 'view_samples', 'samples', 'all');
    res.json(samples);
  });

  app.get("/api/production-orders", requirePermission("inventory.read"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    // Mock data for production orders
    const orders = [
      {
        id: 1,
        orderNumber: "PO001",
        buyerId: 1,
        sampleId: 1,
        quantity: 1000,
        deliveryDate: new Date("2024-05-01"),
        currentStage: "bulk_production",
        stageUpdates: [
          { stage: "pattern", date: "2024-03-01" },
          { stage: "sampling", date: "2024-03-15" },
          { stage: "bulk_production", date: "2024-03-20" }
        ],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        orderNumber: "PO002",
        buyerId: 2,
        sampleId: 2,
        quantity: 500,
        deliveryDate: new Date("2024-04-15"),
        currentStage: "sampling",
        stageUpdates: [
          { stage: "pattern", date: "2024-03-10" },
          { stage: "sampling", date: "2024-03-20" }
        ],
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    await auditLog(req, 'view_production_orders', 'production', 'all');
    res.json(orders);
  });

  // Audit log access (admin only)
  app.get("/api/audit-logs", requirePermission("all"), async (req, res) => {
    const logs = await storage.getAuditLogs();
    res.json(logs);
  });

  // GDPR Endpoints
  app.get("/api/gdpr/purposes", requirePermission("all"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const purposes = [
      {
        id: 1,
        code: "essential",
        description: "Essential data processing for core service functionality",
        isRequired: true,
        active: true
      },
      {
        id: 2,
        code: "analytics",
        description: "Analytics to improve our services",
        isRequired: false,
        active: true
      },
      {
        id: 3,
        code: "marketing",
        description: "Marketing communications and promotions",
        isRequired: false,
        active: true
      }
    ];

    await auditLog(req, 'view_gdpr_purposes', 'gdpr', 'purposes');
    res.json(purposes);
  });

  app.get("/api/gdpr/consents/:userId", requirePermission("all"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.user!.id !== parseInt(req.params.userId) && req.user!.role !== "admin") {
      return res.status(403).json({ message: "Access denied" });
    }

    const consents = {
      1: true,  // Essential (always true)
      2: false, // Analytics
      3: false  // Marketing
    };

    await auditLog(req, 'view_user_consents', 'gdpr', req.params.userId);
    res.json(consents);
  });

  app.post("/api/gdpr/consent", requirePermission("all"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { purposeId, granted } = req.body;

    // Don't allow changing essential consents
    if (purposeId === 1) {
      return res.status(400).json({ message: "Cannot modify essential consents" });
    }

    await auditLog(
      req,
      granted ? 'consent_granted' : 'consent_withdrawn',
      'gdpr',
      `${req.user!.id}_${purposeId}`,
      JSON.stringify({ purposeId, granted })
    );

    res.json({ success: true });
  });

  // GDPR Data Request endpoints
  app.post("/api/gdpr/data-request", requirePermission("all"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    await auditLog(req, 'data_export_requested', 'gdpr', req.user!.id.toString());

    // In a real implementation, this would trigger a background job
    res.json({
      message: "Your data export request has been received. You will be notified when it's ready.",
      requestId: Date.now().toString()
    });
  });

  app.post("/api/gdpr/deletion-request", requirePermission("all"), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    await auditLog(req, 'deletion_requested', 'gdpr', req.user!.id.toString());

    // In a real implementation, this would trigger a background job
    res.json({
      message: "Your account deletion request has been received. This process may take up to 30 days.",
      requestId: Date.now().toString()
    });
  });

  // Public Marketplace endpoints (no auth required)
  app.get("/api/public/marketplace/products", async (req, res) => {
    // Mock data for marketplace products
    const products = [
      {
        id: 1,
        name: "Organic Cotton T-shirts",
        category: "Apparel",
        image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "GOTS certified organic cotton t-shirts with customizable designs. Eco-friendly and sustainable production.",
        minOrderQuantity: 100,
        price: { 
          min: 4.50, 
          max: 7.80, 
          currency: "USD" 
        },
        availableColors: ["White", "Black", "Navy", "Grey", "Red"],
        inStock: true,
        rating: {
          average: 4.7,
          count: 125
        },
        leadTime: "25-30 days",
        featured: true
      },
      {
        id: 2,
        name: "Premium Denim Fabric",
        category: "Fabric",
        image: "https://images.unsplash.com/photo-1582142839970-2b9e04b60f61?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "High-quality denim fabric in various weights and washes. Perfect for jeans, jackets, and accessories.",
        minOrderQuantity: 300,
        price: { 
          min: 3.20, 
          max: 5.90, 
          currency: "USD" 
        },
        availableColors: ["Indigo", "Black", "Blue", "Vintage Wash"],
        inStock: true,
        rating: {
          average: 4.5,
          count: 87
        },
        leadTime: "20-25 days"
      },
      {
        id: 3,
        name: "Premium Linen Fabric",
        category: "Fabric",
        image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "High-quality sustainable linen fabric in various weights. Breathable and perfect for summer garments.",
        minOrderQuantity: 200,
        price: { 
          min: 5.10, 
          max: 8.40, 
          currency: "USD" 
        },
        availableColors: ["Natural", "White", "Sand", "Dusty Blue", "Sage"],
        inStock: true,
        rating: {
          average: 4.8,
          count: 92
        },
        leadTime: "30-35 days",
        featured: true
      },
      {
        id: 4,
        name: "Metal Buttons",
        category: "Accessories",
        image: "https://images.unsplash.com/photo-1614252235316-8c857f398ffc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "Premium quality metal buttons in various sizes and designs. Perfect for jeans, jackets, and shirts.",
        minOrderQuantity: 1000,
        price: { 
          min: 0.15, 
          max: 0.45, 
          currency: "USD" 
        },
        availableColors: ["Silver", "Gold", "Bronze", "Gunmetal"],
        inStock: true,
        rating: {
          average: 4.6,
          count: 104
        },
        leadTime: "10-15 days"
      },
      {
        id: 5,
        name: "Eco-Friendly Packaging",
        category: "Packaging",
        image: "https://images.unsplash.com/photo-1605640486608-2ebc507e1cca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "Biodegradable and recyclable packaging solutions including bags, boxes, and labels.",
        minOrderQuantity: 500,
        price: { 
          min: 0.30, 
          max: 2.50, 
          currency: "USD" 
        },
        availableColors: ["Brown", "White", "Black", "Custom"],
        inStock: true,
        rating: {
          average: 4.9,
          count: 56
        },
        leadTime: "15-20 days",
        featured: true
      },
      {
        id: 6,
        name: "Merino Wool Sweaters",
        category: "Apparel",
        image: "https://images.unsplash.com/photo-1599012307004-a492707edfe4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "Premium quality merino wool sweaters in various styles and patterns. Warm and comfortable.",
        minOrderQuantity: 100,
        price: { 
          min: 18.50, 
          max: 28.75, 
          currency: "USD" 
        },
        availableColors: ["Grey", "Navy", "Black", "Burgundy", "Oatmeal"],
        inStock: false,
        rating: {
          average: 4.7,
          count: 63
        },
        leadTime: "45-60 days"
      },
      {
        id: 7,
        name: "Recycled Polyester",
        category: "Fabric",
        image: "https://images.unsplash.com/photo-1564859228273-274232fdb516?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "Eco-friendly recycled polyester fabric for sustainable clothing production. Reduces plastic waste.",
        minOrderQuantity: 250,
        price: { 
          min: 2.80, 
          max: 5.60, 
          currency: "USD" 
        },
        availableColors: ["White", "Black", "Navy", "Grey", "Custom"],
        inStock: true,
        rating: {
          average: 4.5,
          count: 41
        },
        leadTime: "20-25 days"
      },
      {
        id: 8,
        name: "Custom Woven Labels",
        category: "Accessories",
        image: "https://images.unsplash.com/photo-1586803516349-76cb5f1093d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
        description: "Custom woven labels with your brand logo and information. High quality and durable.",
        minOrderQuantity: 1000,
        price: { 
          min: 0.08, 
          max: 0.25, 
          currency: "USD" 
        },
        availableColors: ["Custom"],
        inStock: true,
        rating: {
          average: 4.8,
          count: 78
        },
        leadTime: "15-20 days"
      }
    ];

    await auditLog(req, 'view_marketplace_products', 'marketplace', 'all');
    res.json(products);
  });

  app.get("/api/public/marketplace/categories", async (req, res) => {
    const categories = [
      { id: 1, name: "Apparel", count: 42 },
      { id: 2, name: "Fabric", count: 37 },
      { id: 3, name: "Accessories", count: 28 },
      { id: 4, name: "Packaging", count: 15 }
    ];
    
    res.json(categories);
  });

  // Public Sample Request API
  app.post("/api/public/sample/request", async (req, res) => {
    const { name, email, company, productName, quantity, specifications } = req.body;
    
    if (!name || !email || !productName) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    
    await auditLog(
      req as Request, 
      'sample_request_submitted', 
      'samples', 
      'public_request', 
      JSON.stringify({ name, email, productName })
    );
    
    res.json({ 
      success: true, 
      message: "Your sample request has been submitted successfully. Our team will contact you shortly.",
      requestId: Date.now().toString()
    });
  });

  // Error handling middleware
  app.use(errorHandler);

  const httpServer = createServer(app);
  return httpServer;
}