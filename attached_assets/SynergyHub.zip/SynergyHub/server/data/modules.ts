export const modules = {
  'Woven Supply': {
    title: 'Woven Supply',
    description: 'Comprehensive vendor relationship management system',
    features: ['VRM for Brands/Retailers', 'Vendor Relationship Management', 'Supply Chain Tracking', 'Bidirectional Feedback'],
    category: 'supply-chain',
    relatedModules: ['Commune Connect', 'Last Smile'],
    weight: 1
  },
  'Commune Connect': {
    title: 'Commune Connect',
    description: 'Build and manage powerful storefronts',
    features: ['Integrated Planning', 'Operations Management', 'Demand Network', 'Cash Flow Tracking'],
    category: 'operations',
    relatedModules: ['Woven Supply', 'Sync Up'],
    weight: 1
  },
  'Last Smile': {
    title: 'Last Smile',
    description: 'End-to-end logistics solution',
    features: ['Support and Returns', 'Logistics and Delivery', 'Last Mile Binding', 'Real-time Updates'],
    category: 'logistics',
    relatedModules: ['Woven Supply', 'Sync Up'],
    weight: 1
  },
  'Sync Up': {
    title: 'Sync Up',
    description: 'Centralized analytics and automation platform',
    features: ['Design and Customization', 'Service Layer Integration', 'Analytics Dashboard', 'Workflow Automation'],
    category: 'analytics',
    relatedModules: ['Commune Connect', 'Last Smile'],
    weight: 1
  }
};
