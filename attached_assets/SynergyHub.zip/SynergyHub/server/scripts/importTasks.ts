import { promises as fs } from 'fs';
import { parse } from 'csv-parse/sync';
import { db } from "@db";
import { tasks } from "@db/schema";

async function importTasksFromCSV(filePath: string, module: string) {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    const records = parse(content, {
      columns: true,
      skip_empty_lines: true
    });

    for (const record of records) {
      if (!record['Task Category']) continue; // Skip empty rows

      await db.insert(tasks).values({
        category: record['Task Category'],
        description: record['Task Description'],
        frequency: record['Frequency'],
        responsible: record['Responsible'],
        status: record['Status'].toLowerCase(),
        remarks: record['Remarks/Notes'],
        module: module
      });
    }

    console.log(`Successfully imported tasks for ${module}`);
  } catch (error) {
    console.error(`Error importing ${module} tasks:`, error);
  }
}

async function importAllTasks() {
  await importTasksFromCSV('attached_assets/Marketplace_Task_Master.csv', 'marketplace');
  await importTasksFromCSV('attached_assets/Buying_House_Task_Master.csv', 'buying_house');
  await importTasksFromCSV('attached_assets/CA_Governance_Task_Master.csv', 'ca_governance');
}

importAllTasks().catch(console.error);
