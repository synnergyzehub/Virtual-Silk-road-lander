import { modules } from "../data/modules";

interface Module {
  title: string;
  description: string;
  features: string[];
  category: string;
  relatedModules: string[];
  weight: number;
}

export class RecommendationEngine {
  private modules: Record<string, Module>;

  constructor() {
    this.modules = modules;
  }

  getRecommendations(currentModule: string, userInteractions: string[] = []): Module[] {
    // Get the current module's data
    const current = this.modules[currentModule];
    if (!current) return [];

    // Calculate scores for each module
    const scores = Object.entries(this.modules).map(([title, module]) => {
      if (title === currentModule) return { module, score: -1 }; // Exclude current module

      let score = 0;

      // Add score for related modules
      if (current.relatedModules.includes(title)) {
        score += 0.5;
      }

      // Add score for category alignment
      if (module.category === current.category) {
        score += 0.3;
      }

      // Add score based on user interactions
      if (userInteractions.includes(title)) {
        score += 0.2;
      }

      // Multiply by module weight
      score *= module.weight;

      return { module, score };
    });

    // Sort by score and return top recommendations
    return scores
      .sort((a, b) => b.score - a.score)
      .filter(item => item.score > 0)
      .map(item => item.module)
      .slice(0, 2);
  }

  updateModuleWeight(moduleName: string, increment: boolean = true) {
    const module = this.modules[moduleName];
    if (module) {
      module.weight += increment ? 0.1 : -0.1;
      module.weight = Math.max(0.1, Math.min(2, module.weight)); // Keep weight between 0.1 and 2
    }
  }
}

export const recommendationEngine = new RecommendationEngine();