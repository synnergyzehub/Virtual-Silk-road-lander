import type { Express } from "express";
import { createServer, type Server } from "http";
import { eq, and } from "drizzle-orm";
import { db } from "@db";
import * as schema from "@db/schema";
import { z } from "zod";
import { recommendationEngine } from "./services/recommendations";

export function registerRoutes(app: Express): Server {
  // Woven Supply Module Routes
  app.get("/api/vendors", async (_req, res) => {
    try {
      const vendors = await db.query.vendors.findMany();
      res.json(vendors);
    } catch (error) {
      res.status(500).json({ message: "Error fetching vendors" });
    }
  });

  app.post("/api/vendors", async (req, res) => {
    try {
      const validatedData = schema.insertVendorSchema.parse(req.body);
      const vendor = await db.insert(schema.vendors).values(validatedData);
      res.status(201).json(vendor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid vendor data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating vendor" });
      }
    }
  });

  // Commune Connect Module Routes
  app.get("/api/stores", async (_req, res) => {
    try {
      const stores = await db.query.stores.findMany();
      res.json(stores);
    } catch (error) {
      res.status(500).json({ message: "Error fetching stores" });
    }
  });

  app.post("/api/stores", async (req, res) => {
    try {
      const validatedData = schema.insertStoreSchema.parse(req.body);
      const store = await db.insert(schema.stores).values(validatedData);
      res.status(201).json(store);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid store data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating store" });
      }
    }
  });

  // Last Smile Module Routes
  app.get("/api/deliveries", async (_req, res) => {
    try {
      const deliveries = await db.query.deliveries.findMany();
      res.json(deliveries);
    } catch (error) {
      res.status(500).json({ message: "Error fetching deliveries" });
    }
  });

  app.post("/api/deliveries", async (req, res) => {
    try {
      const validatedData = schema.insertDeliverySchema.parse(req.body);
      const delivery = await db.insert(schema.deliveries).values(validatedData);
      res.status(201).json(delivery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid delivery data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating delivery" });
      }
    }
  });

  app.get("/api/deliveries/:trackingNumber", async (req, res) => {
    try {
      const delivery = await db.query.deliveries.findFirst({
        where: eq(schema.deliveries.trackingNumber, req.params.trackingNumber),
      });

      if (!delivery) {
        return res.status(404).json({ message: "Delivery not found" });
      }

      res.json(delivery);
    } catch (error) {
      res.status(500).json({ message: "Error fetching delivery" });
    }
  });

  // Sync Up Module Routes
  app.get("/api/workflows", async (_req, res) => {
    try {
      const workflows = await db.query.workflows.findMany();
      res.json(workflows);
    } catch (error) {
      res.status(500).json({ message: "Error fetching workflows" });
    }
  });

  app.post("/api/workflows", async (req, res) => {
    try {
      const validatedData = schema.insertWorkflowSchema.parse(req.body);
      const workflow = await db.insert(schema.workflows).values(validatedData);
      res.status(201).json(workflow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid workflow data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating workflow" });
      }
    }
  });

  // Analytics Routes
  app.post("/api/analytics/session", async (req, res) => {
    try {
      const validatedData = schema.insertUserSessionSchema.parse(req.body);
      const session = await db.insert(schema.userSessions).values(validatedData).returning();
      res.status(201).json(session[0]);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid session data", errors: error.errors });
      } else {
        console.error("Error creating analytics session:", error);
        res.status(500).json({ message: "Error creating session" });
      }
    }
  });

  app.post("/api/analytics/pageview", async (req, res) => {
    try {
      const validatedData = schema.insertPageViewSchema.parse(req.body);
      const pageView = await db.insert(schema.pageViews).values(validatedData).returning();
      res.status(201).json(pageView[0]);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid pageview data", errors: error.errors });
      } else {
        console.error("Error recording pageview:", error);
        res.status(500).json({ message: "Error recording pageview" });
      }
    }
  });

  app.post("/api/analytics/event", async (req, res) => {
    try {
      const validatedData = schema.insertUserEventSchema.parse(req.body);
      const event = await db.insert(schema.userEvents).values(validatedData).returning();
      res.status(201).json(event[0]);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid event data", errors: error.errors });
      } else {
        console.error("Error recording event:", error);
        res.status(500).json({ message: "Error recording event" });
      }
    }
  });

  // Analytics Dashboard Data
  app.get("/api/analytics/summary", async (req, res) => {
    try {
      const [sessions, pageViews, events] = await Promise.all([
        db.query.userSessions.findMany({
          limit: 100,
          orderBy: (userSessions, { desc }) => [desc(userSessions.createdAt)]
        }),
        db.query.pageViews.findMany({
          limit: 100,
          orderBy: (pageViews, { desc }) => [desc(pageViews.createdAt)]
        }),
        db.query.userEvents.findMany({
          limit: 100,
          orderBy: (userEvents, { desc }) => [desc(userEvents.createdAt)]
        })
      ]);

      res.json({
        sessions,
        pageViews,
        events,
        summary: {
          totalSessions: sessions.length,
          totalPageViews: pageViews.length,
          totalEvents: events.length
        }
      });
    } catch (error) {
      console.error("Error fetching analytics data:", error);
      res.status(500).json({ message: "Error fetching analytics data" });
    }
  });

  // Task Management Routes
  app.get("/api/tasks", async (req, res) => {
    try {
      const module = req.query.module as string;
      const tasks = await db.query.tasks.findMany({
        where: module ? eq(schema.tasks.module, module) : undefined,
        orderBy: (tasks, { desc }) => [desc(tasks.createdAt)]
      });
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Error fetching tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const validatedData = schema.insertTaskSchema.parse(req.body);
      const task = await db.insert(schema.tasks).values(validatedData).returning();
      res.status(201).json(task[0]);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        console.error("Error creating task:", error);
        res.status(500).json({ message: "Error creating task" });
      }
    }
  });

  app.patch("/api/tasks/:id/status", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const { status } = req.body;

      const task = await db.query.tasks.findFirst({
        where: eq(schema.tasks.id, taskId)
      });

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      const updatedTask = await db.update(schema.tasks)
        .set({ status, updatedAt: new Date() })
        .where(eq(schema.tasks.id, taskId))
        .returning();

      // Record the status change activity
      await db.insert(schema.taskActivities).values({
        taskId,
        action: 'status_change',
        details: { oldStatus: task.status, newStatus: status }
      });

      res.json(updatedTask[0]);
    } catch (error) {
      console.error("Error updating task status:", error);
      res.status(500).json({ message: "Error updating task status" });
    }
  });

  app.get("/api/tasks/analytics", async (req, res) => {
    try {
      const tasks = await db.query.tasks.findMany();

      const analytics = {
        totalTasks: tasks.length,
        byStatus: tasks.reduce((acc: Record<string, number>, task) => {
          acc[task.status] = (acc[task.status] || 0) + 1;
          return acc;
        }, {}),
        byModule: tasks.reduce((acc: Record<string, number>, task) => {
          acc[task.module] = (acc[task.module] || 0) + 1;
          return acc;
        }, {}),
        byResponsible: tasks.reduce((acc: Record<string, number>, task) => {
          acc[task.responsible] = (acc[task.responsible] || 0) + 1;
          return acc;
        }, {})
      };

      res.json(analytics);
    } catch (error) {
      console.error("Error fetching task analytics:", error);
      res.status(500).json({ message: "Error fetching task analytics" });
    }
  });

  // Module recommendations
  app.get("/api/recommendations/:moduleName", async (req, res) => {
    try {
      const { moduleName } = req.params;
      const userInteractions = req.query.interactions 
        ? (req.query.interactions as string).split(',')
        : [];

      const recommendations = recommendationEngine.getRecommendations(
        moduleName,
        userInteractions
      );

      res.json(recommendations);
    } catch (error) {
      console.error("Error getting recommendations:", error);
      res.status(500).json({ message: "Error fetching recommendations" });
    }
  });

  // Track module interaction
  app.post("/api/recommendations/interaction", async (req, res) => {
    try {
      const { moduleName, interactionType } = req.body;

      // Update module weights based on interaction
      recommendationEngine.updateModuleWeight(
        moduleName, 
        interactionType === 'positive'
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking interaction:", error);
      res.status(500).json({ message: "Error tracking interaction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}