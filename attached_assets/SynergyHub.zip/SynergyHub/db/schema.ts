import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from 'drizzle-orm';

// Base user table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
  role: text("role").notNull().default('user'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Woven Supply Module
export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  contactEmail: text("contact_email").notNull(),
  status: text("status").notNull().default('active'),
  rating: integer("rating"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const supplierRelationships = pgTable("supplier_relationships", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").references(() => vendors.id),
  contractType: text("contract_type").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  terms: jsonb("terms"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Commune Connect Module
export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default('active'),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const demandTracking = pgTable("demand_tracking", {
  id: serial("id").primaryKey(),
  storeId: integer("store_id").references(() => stores.id),
  productType: text("product_type").notNull(),
  quantity: integer("quantity").notNull(),
  priority: text("priority").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Last Smile Module
export const deliveries = pgTable("deliveries", {
  id: serial("id").primaryKey(),
  trackingNumber: text("tracking_number").unique().notNull(),
  status: text("status").notNull(),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  estimatedDelivery: timestamp("estimated_delivery"),
  actualDelivery: timestamp("actual_delivery"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Sync Up Module
export const workflows = pgTable("workflows", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  configuration: jsonb("configuration").notNull(),
  status: text("status").notNull().default('active'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Analytics tables
export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionId: text("session_id").notNull(),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  deviceInfo: jsonb("device_info"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const pageViews = pgTable("page_views", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(), 
  userId: integer("user_id").references(() => users.id),
  path: text("path").notNull(),
  queryParams: jsonb("query_params"),
  viewTime: timestamp("view_time").notNull().defaultNow(),
  timeSpentSeconds: integer("time_spent_seconds"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userEvents = pgTable("user_events", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(), 
  userId: integer("user_id").references(() => users.id),
  eventType: text("event_type").notNull(),
  eventData: jsonb("event_data"),
  occurredAt: timestamp("occurred_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Task Management Tables
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  frequency: text("frequency").notNull(),
  responsible: text("responsible").notNull(),
  status: text("status").notNull().default('pending'),
  remarks: text("remarks"),
  module: text("module").notNull(), // 'marketplace', 'buying_house', or 'ca_governance'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Task activity tracking
export const taskActivities = pgTable("task_activities", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").references(() => tasks.id),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(), // 'status_change', 'comment', etc.
  details: jsonb("details"),
  occurredAt: timestamp("occurred_at").defaultNow(),
});

// Create schemas for all tables
export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);

export const insertVendorSchema = createInsertSchema(vendors);
export const selectVendorSchema = createSelectSchema(vendors);

export const insertStoreSchema = createInsertSchema(stores);
export const selectStoreSchema = createSelectSchema(stores);

export const insertDeliverySchema = createInsertSchema(deliveries);
export const selectDeliverySchema = createSelectSchema(deliveries);

export const insertWorkflowSchema = createInsertSchema(workflows);
export const selectWorkflowSchema = createSelectSchema(workflows);

// Create schemas for new tables
export const insertUserSessionSchema = createInsertSchema(userSessions);
export const selectUserSessionSchema = createSelectSchema(userSessions);

export const insertPageViewSchema = createInsertSchema(pageViews);
export const selectPageViewSchema = createSelectSchema(pageViews);

export const insertUserEventSchema = createInsertSchema(userEvents);
export const selectUserEventSchema = createSelectSchema(userEvents);

// Create schemas for task tables
export const insertTaskSchema = createInsertSchema(tasks);
export const selectTaskSchema = createSelectSchema(tasks);

export const insertTaskActivitySchema = createInsertSchema(taskActivities);
export const selectTaskActivitySchema = createSelectSchema(taskActivities);

// Export types for new tables
export type InsertUserSession = typeof userSessions.$inferInsert;
export type SelectUserSession = typeof userSessions.$inferSelect;

export type InsertPageView = typeof pageViews.$inferInsert;
export type SelectPageView = typeof pageViews.$inferSelect;

export type InsertUserEvent = typeof userEvents.$inferInsert;
export type SelectUserEvent = typeof userEvents.$inferSelect;

// Export types
export type InsertUser = typeof users.$inferInsert;
export type SelectUser = typeof users.$inferSelect;

export type InsertVendor = typeof vendors.$inferInsert;
export type SelectVendor = typeof vendors.$inferSelect;

export type InsertStore = typeof stores.$inferSelect;
export type SelectStore = typeof stores.$inferSelect;

export type InsertDelivery = typeof deliveries.$inferInsert;
export type SelectDelivery = typeof deliveries.$inferSelect;

export type InsertWorkflow = typeof workflows.$inferInsert;
export type SelectWorkflow = typeof workflows.$inferSelect;

// Export types for task tables
export type InsertTask = typeof tasks.$inferInsert;
export type SelectTask = typeof tasks.$inferSelect;

export type InsertTaskActivity = typeof taskActivities.$inferInsert;
export type SelectTaskActivity = typeof taskActivities.$inferSelect;