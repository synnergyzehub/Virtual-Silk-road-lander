import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import HowItWorks from "@/components/HowItWorks";
import Testimonials from "@/components/Testimonials";
import { Button } from "@/components/ui/button";
import { FaLinkedin, FaTwitter, FaFacebook } from "react-icons/fa";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <Testimonials />

        <footer className="bg-gray-50 py-12 mt-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="font-bold text-xl mb-4">Synergyze</h3>
                <p className="text-gray-600 text-sm">
                  Elevating business operations through integrated solutions.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-4">Quick Links</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-600 hover:text-primary">About</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-primary">Contact</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-primary">Privacy Policy</a></li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-4">Products</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-600 hover:text-primary">Woven Supply</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-primary">Commune Connect</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-primary">Last Smile</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-primary">Sync Up</a></li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-4">Follow Us</h4>
                <div className="flex space-x-4">
                  <Button variant="ghost" size="icon">
                    <FaLinkedin className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <FaTwitter className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <FaFacebook className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-600">
              <p>&copy; 2024 Synergyze. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}