import { Helmet } from "react-helmet";
import PlatformHub from "@/components/PlatformHub";
import Navigation from "@/components/Navigation";
import { motion } from "framer-motion";
import { useAnalytics } from "@/lib/analytics";
import { useEffect } from "react";

export default function PlatformHubPage() {
  const { trackPageView } = useAnalytics();

  useEffect(() => {
    trackPageView("/platformhub");
  }, [trackPageView]);

  return (
    <>
      <Helmet>
        <title>Platform Hub | Synnergyze</title>
        <meta name="description" content="Access all Synnergyze modules from one central location. Our unified platform hub connects all your business operations tools." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navigation />
        
        <main className="flex-1">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-gradient-to-b from-background to-muted py-16 px-4 text-center">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Synnergyze Platform Hub
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Your unified access point to all Synnergyze modules and services
              </p>
            </div>
            
            <PlatformHub />
            
            <section className="py-12 bg-muted/50">
              <div className="container mx-auto text-center">
                <h2 className="text-2xl font-bold mb-4">Need assistance?</h2>
                <p className="text-muted-foreground mb-6">
                  Our support team is ready to help you with any questions about our platform
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a 
                    href="mailto:support@synnergyze.com"
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none bg-primary text-primary-foreground hover:bg-primary/90 h-10 py-2 px-4"
                  >
                    Contact Support
                  </a>
                  <a 
                    href="/documentation"
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 py-2 px-4"
                  >
                    View Documentation
                  </a>
                </div>
              </div>
            </section>
          </motion.div>
        </main>
        
        <footer className="bg-muted py-6 px-4 text-center">
          <div className="container mx-auto">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Synnergyze. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </>
  );
}