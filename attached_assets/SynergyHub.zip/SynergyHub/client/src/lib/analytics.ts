import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { nanoid } from 'nanoid';

// Generate a unique session ID
const sessionId = nanoid();

// Simple analytics implementation
export function useAnalytics() {
  const [location] = useLocation();

  useEffect(() => {
    if (!location) return;

    // Simple page view tracking
    fetch('/api/analytics/pageview', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionId,
        path: location,
        viewTime: new Date().toISOString()
      }),
    }).catch(() => {
      // Silently fail - don't disrupt the user experience
    });
  }, [location]);

  // Simple event tracking function
  const trackEvent = (eventType: string, eventData = {}) => {
    fetch('/api/analytics/event', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionId,
        eventType,
        eventData,
        occurredAt: new Date().toISOString()
      }),
    }).catch(() => {
      // Silently fail - don't disrupt the user experience
    });
  };

  return { trackEvent };
}