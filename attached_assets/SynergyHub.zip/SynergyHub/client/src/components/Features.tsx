import { Box, Users, Truck, BarChart } from "lucide-react";
import ModuleCard from "./ModuleCard";
import ModuleRecommendations from "./ModuleRecommendations";
import { motion } from "framer-motion";
import { useState } from "react";

export default function Features() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [userInteractions, setUserInteractions] = useState<string[]>([]);

  const modules = [
    {
      title: "Woven Supply",
      description: "Comprehensive vendor relationship management system with integrated planning and bidirectional feedback. Streamline procurement processes and track supply chain efficiency in real-time.",
      icon: Box,
      href: "https://woven.synnergyze.com",
      features: [
        "VRM for Brands/Retailers",
        "Vendor Relationship Management",
        "Supply Chain Tracking",
        "Bidirectional Feedback"
      ]
    },
    {
      title: "Commune Connect",
      description: "Build and manage powerful storefronts with integrated demand network management. Connect operations, logistics, and procurement in one unified platform.",
      icon: Users,
      href: "https://commune.synnergyze.com",
      features: [
        "Integrated Planning",
        "Operations Management",
        "Demand Network",
        "Cash Flow Tracking"
      ]
    },
    {
      title: "Last Smile",
      description: "End-to-end logistics solution with real-time delivery tracking, support management, and seamless returns processing. Integrate VRM and CRM for complete service coverage.",
      icon: Truck,
      href: "https://lastmile.synnergyze.com",
      features: [
        "Support and Returns",
        "Logistics and Delivery",
        "Last Mile Binding",
        "Real-time Updates"
      ]
    },
    {
      title: "Sync Up",
      description: "Centralized analytics and automation platform. Design customized workflows, track KPIs, and maintain real-time synchronization across all service layers.",
      icon: BarChart,
      href: "https://apps.synnergyze.com",
      features: [
        "Design and Customization",
        "Service Layer Integration",
        "Analytics Dashboard",
        "Workflow Automation"
      ]
    }
  ];

  const handleModuleInteraction = (moduleName: string) => {
    setSelectedModule(moduleName);
    if (!userInteractions.includes(moduleName)) {
      setUserInteractions([...userInteractions, moduleName]);

      // Track interaction
      fetch('/api/recommendations/interaction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          moduleName,
          interactionType: 'positive'
        }),
      }).catch(console.error);
    }
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-3xl font-bold text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Our Solutions
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {modules.map((module, index) => (
            <div 
              key={module.title}
              onClick={() => handleModuleInteraction(module.title)}
            >
              <ModuleCard 
                title={module.title}
                description={module.description}
                icon={module.icon}
                href={module.href}
                features={module.features}
                index={index}
              />
            </div>
          ))}
        </div>

        {selectedModule && (
          <ModuleRecommendations
            currentModule={selectedModule}
            userInteractions={userInteractions}
          />
        )}
      </div>
    </section>
  );
}