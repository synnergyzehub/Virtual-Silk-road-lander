import { ArrowRight, Box, Users, Truck, BarChart } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      title: "Design & Development",
      icon: Box,
      description: "From prototypes to sourcing, we handle the entire development cycle",
      substeps: ["Tech packs creation", "Material sourcing", "Quality standards"]
    },
    {
      title: "Production Planning",
      icon: Users,
      description: "Integrated planning with real-time tracking and coordination",
      substeps: ["Order management", "Production timeline", "Quality control"]
    },
    {
      title: "Logistics & Delivery",
      icon: Truck,
      description: "End-to-end tracking with quality assurance at every step",
      substeps: ["Shipping coordination", "Delivery tracking", "Performance monitoring"]
    },
    {
      title: "Analytics & Reports",
      icon: BarChart,
      description: "Comprehensive reporting and performance analytics",
      substeps: ["Quality reports", "Delivery metrics", "Performance analysis"]
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-6">
          How It Works
        </h2>

        <p className="text-muted-foreground text-center mb-12 max-w-2xl mx-auto">
          A streamlined process that ensures quality and efficiency at every stage
        </p>

        <div className="relative max-w-5xl mx-auto">
          {/* Connecting line */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-200 hidden md:block" />

          <div className="relative grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={step.title} className="relative">
                <div className="bg-white p-6 rounded-lg border shadow-sm relative z-10">
                  {/* Icon and number */}
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <step.icon className="h-6 w-6 text-primary" />
                    </div>
                  </div>

                  {/* Title and description */}
                  <h3 className="text-lg font-semibold mb-2 text-center">{step.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 text-center">{step.description}</p>

                  {/* Substeps */}
                  <ul className="text-sm space-y-2">
                    {step.substeps.map((substep) => (
                      <li key={substep} className="flex items-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2" />
                        {substep}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Connecting arrow */}
                {index < steps.length - 1 && (
                  <ArrowRight className="hidden md:block absolute -right-4 top-1/2 transform -translate-y-1/2 text-gray-400 z-20" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}