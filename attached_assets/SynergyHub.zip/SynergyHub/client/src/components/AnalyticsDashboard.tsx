import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface AnalyticsSummary {
  totalSessions: number;
  totalPageViews: number;
  totalEvents: number;
}

interface PageView {
  id: number;
  path: string;
  viewTime: string;
  sessionId: string;
}

interface UserEvent {
  id: number;
  eventType: string;
  occurredAt: string;
  sessionId: string;
}

interface AnalyticsData {
  summary: AnalyticsSummary;
  pageViews: PageView[];
  events: UserEvent[];
}

export default function AnalyticsDashboard() {
  const { data, isLoading, error } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics/summary"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return <div>Loading analytics...</div>;
  }

  if (error) {
    return <div>Error loading analytics data</div>;
  }

  if (!data) {
    return null;
  }

  return (
    <div className="space-y-6 p-6">
      <h2 className="text-3xl font-bold">Analytics Dashboard</h2>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Total Sessions</CardTitle>
            <CardDescription>Active user sessions</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{data.summary.totalSessions}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Page Views</CardTitle>
            <CardDescription>Total page views</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{data.summary.totalPageViews}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Events</CardTitle>
            <CardDescription>Total tracked events</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{data.summary.totalEvents}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Page Views */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Page Views</CardTitle>
          <CardDescription>Latest user page interactions</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Path</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Session ID</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.pageViews.map((view) => (
                  <TableRow key={view.id}>
                    <TableCell>{view.path}</TableCell>
                    <TableCell>
                      {new Date(view.viewTime).toLocaleString()}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {view.sessionId}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Recent Events */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Events</CardTitle>
          <CardDescription>Latest user interactions</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event Type</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Session ID</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.events.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>{event.eventType}</TableCell>
                    <TableCell>
                      {new Date(event.occurredAt).toLocaleString()}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {event.sessionId}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}