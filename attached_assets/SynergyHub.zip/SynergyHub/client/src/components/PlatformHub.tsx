import { ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { useAnalytics } from "@/lib/analytics";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const moduleData = [
  {
    title: "Woven Supply",
    description: "Comprehensive vendor relationship management system with integrated planning and bidirectional feedback. Streamline procurement processes and track supply chain efficiency in real-time.",
    url: "https://woven.synnergyze.com",
    category: "Supply Chain",
    tags: ["VRM", "Supply Chain", "Procurement"]
  },
  {
    title: "Commune Connect",
    description: "Build and manage powerful storefronts with integrated demand network management. Connect operations, logistics, and procurement in one unified platform.",
    url: "https://commune.synnergyze.com",
    category: "Operations",
    tags: ["Planning", "Operations", "Demand"]
  },
  {
    title: "Last Smile",
    description: "End-to-end logistics solution with real-time delivery tracking, support management, and seamless returns processing. Integrate VRM and CRM for complete service coverage.",
    url: "https://lastmile.synnergyze.com",
    category: "Logistics",
    tags: ["Support", "Logistics", "Delivery"]
  },
  {
    title: "Sync Up",
    description: "Centralized analytics and automation platform. Design customized workflows, track KPIs, and maintain real-time synchronization across all service layers.",
    url: "https://apps.synnergyze.com",
    category: "Analytics",
    tags: ["Design", "Integration", "Analytics"]
  }
];

export default function PlatformHub() {
  const { trackEvent } = useAnalytics();

  const handleModuleClick = (moduleTitle: string) => {
    trackEvent({
      type: "MODULE_LINK_CLICK",
      data: { module: moduleTitle }
    });
  };

  return (
    <section className="py-12 px-4 md:px-6 lg:py-16">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold tracking-tight mb-2">Synnergyze Platform Hub</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Access all your integrated business operation modules from one central location
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {moduleData.map((module, index) => (
            <motion.div
              key={module.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-2xl">{module.title}</CardTitle>
                    <Badge variant="outline">{module.category}</Badge>
                  </div>
                  <CardDescription className="text-sm mt-2">{module.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {module.tags.map(tag => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="default" 
                    className="w-full"
                    onClick={() => handleModuleClick(module.title)}
                    asChild
                  >
                    <a href={module.url} target="_blank" rel="noopener noreferrer">
                      Launch {module.title} <ExternalLink size={16} className="ml-2" />
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}