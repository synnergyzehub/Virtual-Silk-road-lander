import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Testimonials() {
  const testimonials = [
    {
      quote: "Synergyze has transformed how we manage our supply chain. The integration between modules is seamless.",
      author: "Sarah Johnson",
      role: "Operations Director",
      company: "TechCorp",
      avatar: "SJ",
    },
    {
      quote: "The platform's automation capabilities have saved us countless hours in manual processes.",
      author: "Michael Chen",
      role: "Supply Chain Manager",
      company: "Global Logistics",
      avatar: "MC",
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          What Our Clients Say
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.author}>
              <CardContent className="p-6">
                <blockquote className="text-lg text-gray-700 mb-6">
                  "{testimonial.quote}"
                </blockquote>
                
                <div className="flex items-center">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                  </Avatar>
                  
                  <div className="ml-4">
                    <div className="font-semibold">{testimonial.author}</div>
                    <div className="text-sm text-muted-foreground">
                      {testimonial.role} at {testimonial.company}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
