import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";
import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";

interface ModuleCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  features: string[];
  index: number;
}

export default function ModuleCard({
  title,
  description,
  icon: Icon,
  href,
  features,
  index,
}: ModuleCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.5,
        delay: index * 0.1,
        ease: "easeOut"
      }}
      whileHover={{ 
        y: -8,
        transition: { duration: 0.2 }
      }}
    >
      <Card className="group relative overflow-hidden hover:shadow-xl transition-all duration-300 hover:bg-primary/5">
        <CardHeader>
          <motion.div 
            className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4"
            whileHover={{ 
              rotate: 360,
              scale: 1.2,
              transition: { duration: 0.6, type: "spring" }
            }}
            whileTap={{ scale: 0.9 }}
          >
            <Icon className="h-6 w-6 text-primary" />
          </motion.div>
          <motion.h3 
            className="text-xl font-semibold"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.2 }}
          >
            {title}
          </motion.h3>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-6">{description}</p>

          <motion.ul 
            className="space-y-2 mb-6"
            initial="hidden"
            animate="visible"
            variants={{
              visible: {
                transition: {
                  staggerChildren: 0.1
                }
              }
            }}
          >
            {features.map((feature, i) => (
              <motion.li
                key={feature}
                variants={{
                  hidden: { opacity: 0, x: -20 },
                  visible: { opacity: 1, x: 0 }
                }}
                whileHover={{ x: 4 }}
                className="flex items-start"
              >
                <motion.div
                  whileHover={{ scale: 1.2, rotate: 360 }}
                  transition={{ duration: 0.3 }}
                >
                  <Check className="h-4 w-4 text-primary mt-1 mr-2 flex-shrink-0" />
                </motion.div>
                <span className="text-sm">{feature}</span>
              </motion.li>
            ))}
          </motion.ul>

          <Button
            variant="ghost"
            className="relative w-full overflow-hidden group"
            asChild
          >
            <motion.a 
              href={href}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="relative z-10 flex items-center justify-center">
                Learn More
                <motion.div
                  className="ml-2"
                  whileHover={{ x: 4 }}
                  transition={{ duration: 0.2 }}
                >
                  <ArrowRight className="h-4 w-4" />
                </motion.div>
              </span>
              <motion.div
                className="absolute inset-0 bg-primary/10 transform origin-left"
                initial={{ scaleX: 0 }}
                whileHover={{ scaleX: 1 }}
                transition={{ duration: 0.3 }}
              />
            </motion.a>
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}