import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import ModuleCard from "./ModuleCard";

interface RecommendedModule {
  title: string;
  description: string;
  features: string[];
  category: string;
}

interface ModuleRecommendationsProps {
  currentModule: string;
  userInteractions?: string[];
}

export default function ModuleRecommendations({ 
  currentModule,
  userInteractions = []
}: ModuleRecommendationsProps) {
  const { data: recommendations, isLoading } = useQuery<RecommendedModule[]>({
    queryKey: [
      '/api/recommendations', 
      currentModule, 
      userInteractions.join(',')
    ],
    queryFn: async () => {
      const params = new URLSearchParams({
        interactions: userInteractions.join(',')
      });
      const response = await fetch(
        `/api/recommendations/${currentModule}?${params}`
      );
      if (!response.ok) throw new Error('Failed to fetch recommendations');
      return response.json();
    },
    enabled: !!currentModule
  });

  if (isLoading || !recommendations?.length) return null;

  return (
    <div className="mt-20 py-12 bg-primary/5 rounded-xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto px-4"
      >
        <h3 className="text-2xl font-semibold mb-8 text-center">
          Recommended Solutions for You
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {recommendations.map((module, index) => (
            <ModuleCard
              key={module.title}
              title={module.title}
              description={module.description}
              icon={ArrowRight}
              features={module.features}
              href={`https://${module.title.toLowerCase().replace(' ', '')}.synnergyze.com`}
              index={index}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}