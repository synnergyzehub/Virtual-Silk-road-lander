import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Suspense, lazy } from "react";
import { useAnalytics } from "@/lib/analytics";

// Lazy load components for better performance
const AnalyticsDashboard = lazy(() => import("@/components/AnalyticsDashboard"));
const PlatformHubPage = lazy(() => import("@/pages/PlatformHub"));

function Router() {
  // Initialize analytics tracking
  useAnalytics();

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route 
        path="/analytics" 
        component={() => (
          <Suspense fallback={<div>Loading analytics...</div>}>
            <AnalyticsDashboard />
          </Suspense>
        )} 
      />
      <Route 
        path="/platform" 
        component={() => (
          <Suspense fallback={<div>Loading platform hub...</div>}>
            <PlatformHubPage />
          </Suspense>
        )} 
      />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <Router />
        <Toaster />
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;