import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { DataProcessingPurpose } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

type ConsentPurpose = {
  id: number;
  code: string;
  description: string;
  isRequired: boolean;
  active: boolean;
};

export function ConsentManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [consents, setConsents] = useState<Record<string, boolean>>({});

  const { data: purposes, isLoading: purposesLoading } = useQuery<ConsentPurpose[]>({
    queryKey: ["/api/gdpr/purposes"],
  });

  const { data: currentConsents, isLoading: consentsLoading } = useQuery<Record<string, boolean>>({
    queryKey: ["/api/gdpr/consents", user?.id],
  });

  const updateConsentMutation = useMutation({
    mutationFn: async (data: { purposeId: number; granted: boolean }) => {
      const res = await apiRequest(
        "POST",
        "/api/gdpr/consent",
        data
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gdpr/consents", user?.id] });
      toast({
        title: "Preferences Updated",
        description: "Your privacy preferences have been saved.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (purposesLoading || consentsLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Privacy Preferences</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <p className="text-sm text-muted-foreground">
          Control how your data is collected and used. Required preferences cannot be disabled as they are essential for the service to function.
        </p>

        {purposes?.map((purpose) => (
          <div key={purpose.id} className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">{purpose.code}</h3>
              <p className="text-sm text-muted-foreground">{purpose.description}</p>
            </div>
            <Switch
              checked={consents[purpose.id] || purpose.isRequired}
              disabled={purpose.isRequired}
              onCheckedChange={(checked) => {
                setConsents(prev => ({ ...prev, [purpose.id]: checked }));
                updateConsentMutation.mutate({
                  purposeId: purpose.id,
                  granted: checked
                });
              }}
            />
          </div>
        ))}

        <div className="border-t pt-4">
          <p className="text-sm text-muted-foreground">
            You can request a copy of your data or ask for it to be deleted by contacting our support team.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}