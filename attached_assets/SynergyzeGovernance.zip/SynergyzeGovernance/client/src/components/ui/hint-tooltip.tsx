import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface HintTooltipProps {
  id: string;
  title: string;
  message: string;
  position: "top" | "right" | "bottom" | "left";
  element: React.ReactNode;
  onCompleted?: () => void;
  show?: boolean;
}

export function HintTooltip({
  id,
  title,
  message,
  position,
  element,
  onCompleted,
  show = true,
}: HintTooltipProps) {
  const [dismissed, setDismissed] = useLocalStorage<string[]>("dismissed-hints", []);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Only show the hint if it hasn't been dismissed and the show prop is true
    if (show && !dismissed.includes(id)) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1000); // Delay to let the page render first
      
      return () => clearTimeout(timer);
    }
  }, [id, dismissed, show]);
  
  const handleDismiss = () => {
    setIsVisible(false);
    setDismissed([...dismissed, id]);
    if (onCompleted) {
      onCompleted();
    }
  };
  
  if (dismissed.includes(id) || !show) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="inline-block cursor-help">{element}</div>
        </TooltipTrigger>
        <TooltipContent side={position}>
          <div className="max-w-xs">
            <p className="font-medium">{title}</p>
            <p className="text-sm text-muted-foreground">{message}</p>
          </div>
        </TooltipContent>
      </Tooltip>
    );
  }
  
  if (!isVisible) {
    return <>{element}</>;
  }
  
  return (
    <div className="relative">
      {element}
      <div 
        className={`absolute z-50 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 max-w-xs ${
          position === "top" ? "bottom-full mb-2" :
          position === "bottom" ? "top-full mt-2" :
          position === "left" ? "right-full mr-2" :
          "left-full ml-2"
        }`}
      >
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-blue-500" />
            <h3 className="font-medium">{title}</h3>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-6 w-6 p-0 rounded-full"
            onClick={handleDismiss}
          >
            <X className="h-3 w-3" />
            <span className="sr-only">Dismiss</span>
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">{message}</p>
      </div>
    </div>
  );
}