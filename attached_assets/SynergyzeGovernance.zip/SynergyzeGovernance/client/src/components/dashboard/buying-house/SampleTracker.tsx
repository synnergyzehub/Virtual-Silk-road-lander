import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Sample } from "@shared/schema";
import { Loader2 } from "lucide-react";

export function SampleTracker() {
  const { data: samples, isLoading } = useQuery<Sample[]>({
    queryKey: ["/api/samples"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sample Development</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {samples?.map((sample) => (
            <div
              key={sample.id}
              className="flex items-center justify-between border-b pb-4"
            >
              <div>
                <p className="font-medium">{sample.productName}</p>
                <p className="text-sm text-muted-foreground">
                  Sample #{sample.sampleNumber}
                </p>
              </div>
              <Badge
                variant={
                  sample.status === "approved"
                    ? "success"
                    : sample.status === "rejected"
                    ? "destructive"
                    : "default"
                }
              >
                {sample.status}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
