import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LogOut, User, Home, Package, ShoppingBag } from "lucide-react";
import { Link, useLocation } from "wouter";

export function HeaderNav() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <header className="border-b bg-card">
      <div className="flex h-16 items-center px-6 justify-between">
        <div className="flex items-center gap-3">
          <img src="/generated-icon.png" alt="Synergyze Logo" className="h-8 w-8" />
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text">
            Synergyze Dashboard
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              <span>Synergyze.com</span>
            </Button>
          </Link>
          
          <Link href="/buying-house">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              <span>Woven Supply</span>
            </Button>
          </Link>
          
          <Link href="/marketplace">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <ShoppingBag className="h-4 w-4" />
              <span>Commune Connect</span>
            </Button>
          </Link>
          
          <Avatar>
            <AvatarFallback>
              <User className="h-5 w-5" />
            </AvatarFallback>
          </Avatar>
          <div className="text-sm">
            <p className="font-medium">{user?.username}</p>
            <p className="text-muted-foreground">{user?.role.replace('_', ' ')}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              logoutMutation.mutate();
              setLocation("/");
            }}
            title="Logout"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}
