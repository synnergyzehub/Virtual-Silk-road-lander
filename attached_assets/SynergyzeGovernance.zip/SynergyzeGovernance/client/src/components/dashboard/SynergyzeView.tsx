import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export function SynergyzeView() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold">Synergyze Finance</h2>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Financial Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Coming soon: Financial metrics and transactions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Payment Processing</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Coming soon: Payment processing and reconciliation</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
