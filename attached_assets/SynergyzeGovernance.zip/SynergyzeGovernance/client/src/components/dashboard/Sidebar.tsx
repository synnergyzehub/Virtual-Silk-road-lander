import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Package, ShoppingCart, CreditCard, Store, LayoutGrid, ExternalLink, Home, Shield } from "lucide-react";
import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  currentView: string;
  onViewChange: (view: "woven" | "commune" | "synergyze") => void;
}

export function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  
  return (
    <div className="w-64 border-r bg-card h-[calc(100vh-4rem)] p-4 overflow-y-auto sidebar-nav">
      <div className="py-2">
        <h3 className="text-sm font-medium mb-2 text-muted-foreground px-4">Admin Dashboard</h3>
        <nav className="space-y-1">
          <Button
            variant={currentView === "woven" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => onViewChange("woven")}
          >
            <Package className="mr-2 h-4 w-4" />
            Woven Supply
          </Button>
          <Button
            variant={currentView === "commune" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => onViewChange("commune")}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Commune Connect
          </Button>
          <Button
            variant={currentView === "synergyze" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => onViewChange("synergyze")}
          >
            <CreditCard className="mr-2 h-4 w-4" />
            Synergyze Finance
          </Button>
        </nav>
      </div>
      
      <Separator className="my-4" />
      
      <div className="py-2">
        <h3 className="text-sm font-medium mb-2 text-muted-foreground px-4">Network Portals</h3>
        <nav className="space-y-1">
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Synergyze.com
              <ExternalLink className="ml-auto h-3 w-3 opacity-60" />
            </Link>
          </Button>
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/buying-house">
              <Store className="mr-2 h-4 w-4" />
              Woven Supply Marketplace
              <ExternalLink className="ml-auto h-3 w-3 opacity-60" />
            </Link>
          </Button>
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/marketplace">
              <LayoutGrid className="mr-2 h-4 w-4" />
              Commune Connect Network
              <ExternalLink className="ml-auto h-3 w-3 opacity-60" />
            </Link>
          </Button>
        </nav>
      </div>
      
      {isAdmin && (
        <>
          <Separator className="my-4" />
          
          <div className="py-2">
            <h3 className="text-sm font-medium mb-2 text-muted-foreground px-4">Super Admin</h3>
            <nav className="space-y-1">
              <Button variant="ghost" className="w-full justify-start">
                <Shield className="mr-2 h-4 w-4" />
                Governance Controls
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Shield className="mr-2 h-4 w-4" />
                License Management
              </Button>
            </nav>
          </div>
        </>
      )}
    </div>
  );
}
