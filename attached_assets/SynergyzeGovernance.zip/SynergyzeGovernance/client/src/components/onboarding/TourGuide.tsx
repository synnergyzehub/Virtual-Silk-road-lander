import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { useTour } from "@/hooks/use-tour";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

export type TourStep = {
  title: string;
  description: string;
  image?: string;
  highlight?: string; // CSS selector to highlight
  placement?: "top" | "right" | "bottom" | "left";
};

export type Tour = {
  id: string;
  name: string;
  steps: TourStep[];
};

// Define tours for different parts of the application
const tours: { [key: string]: Tour } = {
  dashboard: {
    id: "dashboard-tour",
    name: "Dashboard Tour",
    steps: [
      {
        title: "Welcome to Your Dashboard",
        description: "This is your central hub for managing all supply chain operations. Let's explore the key features available to you.",
        highlight: ".dashboard-overview"
      },
      {
        title: "Navigation Sidebar",
        description: "Use this sidebar to switch between different platforms: Woven Supply, Commune Connect, and Synergyze.",
        highlight: ".sidebar-nav"
      },
      {
        title: "Quick Actions",
        description: "Access frequently used actions from this panel to streamline your workflow.",
        highlight: ".quick-actions"
      },
      {
        title: "Analytics Overview",
        description: "Monitor key performance metrics and trends at a glance in these dashboard cards.",
        highlight: ".analytics-cards"
      }
    ]
  },
  marketplace: {
    id: "marketplace-tour",
    name: "Marketplace Tour",
    steps: [
      {
        title: "Welcome to the Marketplace",
        description: "Browse and purchase products from approved vendors in our marketplace.",
        highlight: ".marketplace-header"
      },
      {
        title: "Product Categories",
        description: "Filter products by category to find exactly what you need.",
        highlight: ".category-filters"
      },
      {
        title: "Product Search",
        description: "Use the search bar to quickly find specific items by name or description.",
        highlight: ".search-container"
      },
      {
        title: "Product Details",
        description: "Click on any product to view detailed information, specifications, and pricing.",
        highlight: ".product-grid"
      }
    ]
  },
  buying_house: {
    id: "buying-house-tour",
    name: "Buying House Tour",
    steps: [
      {
        title: "Welcome to the Buying House",
        description: "This is where you can manage sample requests and production orders with our vendors.",
        highlight: ".buying-house-header"
      },
      {
        title: "Sample Requests",
        description: "Create and track sample requests from this section.",
        highlight: ".sample-request-form"
      },
      {
        title: "Production Tracking",
        description: "Monitor the status of your production orders throughout the manufacturing process.",
        highlight: ".production-tracker"
      },
      {
        title: "Product Catalog",
        description: "Browse our catalog of available products and materials.",
        highlight: ".product-catalog"
      }
    ]
  }
};

interface TourGuideProps {
  forceStart?: boolean;
}

export function TourGuide({ forceStart = false }: TourGuideProps) {
  // Create a safe version of useTour that doesn't crash if context is missing
  const tourContext = (() => {
    try {
      return useTour();
    } catch (error) {
      return { currentPage: "" };
    }
  })();
  
  const { currentPage } = tourContext;
  const [open, setOpen] = useState(false);
  const [currentTourId, setCurrentTourId] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedTours, setCompletedTours] = useLocalStorage<string[]>("completed-tours", []);
  
  // Determine which tour to show based on the current page
  useEffect(() => {
    let tourId: string | null = null;
    
    if (currentPage === "dashboard" || currentPage === "") {
      tourId = "dashboard";
    } else if (currentPage === "marketplace") {
      tourId = "marketplace";
    } else if (currentPage === "buying-house") {
      tourId = "buying_house";
    }
    
    // Automatically start the tour if it hasn't been completed yet, or if forceStart is true
    if (tourId && (forceStart || !completedTours.includes(tourId))) {
      setCurrentTourId(tourId);
      setCurrentStep(0);
      setOpen(true);
    }
  }, [currentPage, completedTours, forceStart]);
  
  // Handle highlighting elements based on the current step
  useEffect(() => {
    if (open && currentTourId && tours[currentTourId]) {
      const currentTour = tours[currentTourId];
      const step = currentTour.steps[currentStep];
      
      // Remove any existing highlights
      document.querySelectorAll('.tour-highlight').forEach(el => {
        el.classList.remove('tour-highlight');
      });
      
      // Add highlight to the current step's element if specified
      if (step.highlight) {
        const elements = document.querySelectorAll(step.highlight);
        elements.forEach(el => {
          el.classList.add('tour-highlight');
        });
      }
    }
    
    return () => {
      // Clean up highlights when component unmounts
      document.querySelectorAll('.tour-highlight').forEach(el => {
        el.classList.remove('tour-highlight');
      });
    };
  }, [open, currentTourId, currentStep]);
  
  const handleComplete = () => {
    if (currentTourId && !completedTours.includes(currentTourId)) {
      setCompletedTours([...completedTours, currentTourId]);
    }
    setOpen(false);
  };
  
  const handleNext = () => {
    if (currentTourId) {
      const totalSteps = tours[currentTourId].steps.length;
      if (currentStep < totalSteps - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        handleComplete();
      }
    }
  };
  
  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  // If no tour is active, don't render anything
  if (!open || !currentTourId || !tours[currentTourId]) {
    return null;
  }
  
  const tour = tours[currentTourId];
  const step = tour.steps[currentStep];
  const totalSteps = tour.steps.length;
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <div className="flex items-center justify-between">
          <DialogTitle>{step.title}</DialogTitle>
          <Badge variant="outline" className="ml-2">
            Step {currentStep + 1} of {totalSteps}
          </Badge>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setOpen(false)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        <DialogDescription className="pt-4 pb-6">
          {step.description}
        </DialogDescription>
        {step.image && (
          <div className="rounded-md overflow-hidden mb-4">
            <img src={step.image} alt={step.title} className="w-full h-auto" />
          </div>
        )}
        <DialogFooter className="flex justify-between sm:justify-between">
          <div>
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className="mr-2"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleComplete}
            >
              Skip Tour
            </Button>
          </div>
          <Button size="sm" onClick={handleNext}>
            {currentStep < totalSteps - 1 ? (
              <>
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </>
            ) : (
              "Finish"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}