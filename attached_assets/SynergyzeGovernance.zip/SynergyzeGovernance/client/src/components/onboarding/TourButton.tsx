import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface TourButtonProps {
  tourId: string;
  onStartTour: () => void;
}

export function TourButton({ tourId, onStartTour }: TourButtonProps) {
  const [completedTours] = useLocalStorage<string[]>("completed-tours", []);
  const isCompleted = completedTours.includes(tourId);

  return (
    <Button
      variant={isCompleted ? "outline" : "default"}
      size="sm"
      onClick={onStartTour}
      className="flex items-center gap-1"
    >
      <HelpCircle className="h-4 w-4" />
      <span>{isCompleted ? "View Tour Again" : "Take Tour"}</span>
    </Button>
  );
}