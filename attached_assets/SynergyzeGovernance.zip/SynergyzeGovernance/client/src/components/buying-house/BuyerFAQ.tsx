import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

type FAQItem = {
  question: string;
  answer: string;
  category: "general" | "samples" | "production" | "marketplace" | "shipping";
};

const faqs: FAQItem[] = [
  {
    question: "What is a buying house, and how does it work?",
    answer: "A buying house acts as an intermediary between international buyers and local manufacturers. We manage product development, quality control, and logistics to ensure smooth production and timely delivery. Our team takes care of every aspect from sample development to production and shipping.",
    category: "general",
  },
  {
    question: "How do I start working with your buying house?",
    answer: "To start working with us, you can begin by submitting a sample request through our portal. Our team will review your requirements and get back to you within 48 hours. Alternatively, you can register for an account and then explore our marketplace for ready-to-order products.",
    category: "general",
  },
  {
    question: "What information do I need to provide for a sample request?",
    answer: "For a sample request, you should provide details like product type, specifications (size, color, material), quantity needed, target price, and any reference images or technical drawings. The more detailed your request, the better we can match your requirements.",
    category: "samples",
  },
  {
    question: "How long does sample development take?",
    answer: "Sample development typically takes 1-3 weeks depending on the complexity of the product and availability of materials. After your request is submitted, we'll provide you with an estimated timeline for your specific product.",
    category: "samples",
  },
  {
    question: "What happens after my sample is approved?",
    answer: "Once your sample is approved, you can place a production order. We'll finalize pricing, create a detailed production timeline, and begin manufacturing according to the approved sample specifications.",
    category: "samples",
  },
  {
    question: "What is the minimum order quantity (MOQ)?",
    answer: "Minimum order quantities vary by product type and manufacturer. Generally, apparel items have MOQs ranging from 300-500 pieces per style and color. Custom-made products typically have higher MOQs. Specific MOQs are listed on each product in our marketplace.",
    category: "production",
  },
  {
    question: "How do I track my production order?",
    answer: "You can track your production order through our Order Tracking section. Each order has a unique number that allows you to monitor its progress through different production stages from pattern making to shipping.",
    category: "production",
  },
  {
    question: "What quality control measures do you implement?",
    answer: "We implement multiple quality control checkpoints throughout the production process. This includes pre-production material inspection, in-line quality checks during manufacturing, and final random sampling inspection before shipping. Quality reports are available in your order details.",
    category: "production",
  },
  {
    question: "How can I purchase products from the marketplace?",
    answer: "You can browse our marketplace catalog, add products to your cart, and proceed to checkout. For marketplace products, no sample development is needed as these are ready-to-order items with established specifications and pricing.",
    category: "marketplace",
  },
  {
    question: "Can I customize products available in the marketplace?",
    answer: "Yes, many marketplace products offer customization options such as color, size range, or branding. Look for the 'Customizable' badge on product listings. For extensive modifications, we recommend submitting a sample request instead.",
    category: "marketplace",
  },
  {
    question: "What shipping methods are available?",
    answer: "We offer air freight, sea freight, and express courier options. The best method depends on your timeline, budget, and order volume. Our team can recommend the most suitable shipping method based on your specific requirements.",
    category: "shipping",
  },
  {
    question: "How are shipping costs calculated?",
    answer: "Shipping costs are calculated based on the weight/volume of the shipment, destination, shipping method, and any additional services required (like special packaging or insurance). A detailed shipping quote is provided before finalizing your order.",
    category: "shipping",
  },
];

export default function BuyerFAQ() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const filteredFAQs = faqs.filter(
    (faq) =>
      (selectedCategory === "all" || faq.category === selectedCategory) &&
      (faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
          <CardDescription>
            Find answers to common questions about our buying house services, sample development, production processes, and more.
          </CardDescription>
          
          <div className="pt-4">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="mb-6 flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
            >
              All Categories
            </Button>
            <Button
              variant={selectedCategory === "general" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("general")}
            >
              General
            </Button>
            <Button
              variant={selectedCategory === "samples" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("samples")}
            >
              Samples
            </Button>
            <Button
              variant={selectedCategory === "production" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("production")}
            >
              Production
            </Button>
            <Button
              variant={selectedCategory === "marketplace" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("marketplace")}
            >
              Marketplace
            </Button>
            <Button
              variant={selectedCategory === "shipping" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("shipping")}
            >
              Shipping
            </Button>
          </div>

          {filteredFAQs.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No matching FAQs found. Try a different search term or category.</p>
            </div>
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {filteredFAQs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}

          <div className="mt-8 bg-muted p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Still have questions?</h3>
            <p className="text-muted-foreground mb-4">
              If you couldn't find the answer to your question, please contact our support team.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button variant="outline">
                Contact Support
              </Button>
              <Button>
                Schedule a Consultation
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}