import { Button } from "@/components/ui/button";
import { LogOut, Package, Search, ShoppingCart, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

export default function BuyingHouseHeader() {
  const [searchQuery, setSearchQuery] = useState("");
  const [cartCount, setCartCount] = useState(0);
  
  // Handle auth context safely
  let user = null;
  let logoutMutation = { mutate: () => console.log("Logout") };
  
  try {
    // Dynamic import of useAuth to prevent errors when not in AuthProvider context
    const { useAuth } = require("@/hooks/use-auth");
    const auth = useAuth();
    if (auth) {
      user = auth.user;
      logoutMutation = auth.logoutMutation;
    }
  } catch (error) {
    console.log("Auth context not available");
  }
  
  return (
    <div className="bg-primary text-primary-foreground">
      <div className="container mx-auto py-4 px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="h-8 w-8" />
            <span className="text-xl font-bold">Woven Supply</span>
          </div>
          
          <div className="flex-1 max-w-md mx-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search products, materials, etc."
                className="w-full bg-primary-foreground text-primary pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-primary" />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full text-xs w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                {user ? (
                  <div className="flex items-center gap-2 px-3 py-2 rounded-md border border-input">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">
                        {user.username.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{user.username}</span>
                  </div>
                ) : (
                  <Button variant="outline" size="icon">
                    <User className="h-5 w-5" />
                  </Button>
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {user ? (
                  <>
                    <div className="p-2">
                      <p className="text-sm font-medium">{user.username}</p>
                      <p className="text-xs text-muted-foreground">{user.role.replace('_', ' ')}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>My Orders</DropdownMenuItem>
                    <DropdownMenuItem>Sample Requests</DropdownMenuItem>
                    <DropdownMenuItem>My Account</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/">Dashboard</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => logoutMutation.mutate()}
                      className="text-destructive focus:text-destructive"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem asChild>
                      <Link href="/synergyhub">Login / Register</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>My Orders</DropdownMenuItem>
                    <DropdownMenuItem>Sample Requests</DropdownMenuItem>
                    <DropdownMenuItem>My Account</DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button variant="outline" asChild>
              <Link href="/marketplace">Marketplace</Link>
            </Button>
            <Button>Request Quote</Button>
          </div>
        </div>
      </div>
    </div>
  );
}