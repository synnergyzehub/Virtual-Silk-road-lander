import { useQuery } from "@tanstack/react-query";
import { Loader2, Filter, ShoppingCart, ExternalLink } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useState } from "react";

type Product = {
  id: number;
  name: string;
  category: string;
  image?: string;
  description: string;
  minOrderQuantity: number;
  price: { 
    min: number; 
    max: number; 
    currency: string 
  };
  availableColors: string[];
  inStock: boolean;
};

export default function ProductCatalog() {
  const [category, setCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("popularity");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/public/products"],
  });

  if (isLoading || !products) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const filteredProducts = products
    .filter(product => 
      (category === "all" || product.category === category) &&
      (searchQuery === "" || 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortBy === "price-low") {
        return a.price.min - b.price.min;
      } else if (sortBy === "price-high") {
        return b.price.min - a.price.min;
      }
      // Default: popularity (using id as proxy since we don't have real data)
      return a.id - b.id;
    });

  return (
    <div>
      <div className="mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="w-full md:w-1/3">
          <Input
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-4 items-center">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter:</span>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="Apparel">Apparel</SelectItem>
                <SelectItem value="Fabric">Fabric</SelectItem>
                <SelectItem value="Accessories">Accessories</SelectItem>
                <SelectItem value="Packaging">Packaging</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span>Sort by:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Popularity</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {filteredProducts.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">No products found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-video bg-muted relative flex items-center justify-center">
        {product.image ? (
          <img 
            src={product.image} 
            alt={product.name} 
            className="object-cover w-full h-full" 
          />
        ) : (
          <div className="flex items-center justify-center h-full w-full bg-secondary/20">
            <span className="text-muted-foreground">No image</span>
          </div>
        )}
        {!product.inStock && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
            <Badge variant="destructive" className="text-lg font-medium">
              Out of Stock
            </Badge>
          </div>
        )}
      </div>
      
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{product.name}</CardTitle>
          <Badge variant="outline">{product.category}</Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-muted-foreground text-sm mb-4">{product.description}</p>
        
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm">Price Range:</span>
            <span className="font-medium">
              {product.price.currency} {product.price.min} - {product.price.max}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm">Min. Order:</span>
            <span>{product.minOrderQuantity} pcs</span>
          </div>
          
          <div className="mt-3">
            <span className="text-sm block mb-1">Available Colors:</span>
            <div className="flex flex-wrap gap-1">
              {product.availableColors.map((color, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {color}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex gap-2">
        <Button variant="outline" className="flex-1" size="sm">
          <ExternalLink className="h-4 w-4 mr-2" />
          Details
        </Button>
        <Button className="flex-1" size="sm" disabled={!product.inStock}>
          <ShoppingCart className="h-4 w-4 mr-2" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}