import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ArrowRight, Star, Truck, ShoppingCart } from "lucide-react";

export default function MarketplaceFeatured() {
  const featuredProducts = [
    {
      id: 1,
      name: "Organic Cotton T-shirts",
      description: "GOTS certified organic cotton t-shirts with customizable designs",
      image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
      tag: "Best Seller",
      tagColor: "bg-amber-500"
    },
    {
      id: 2,
      name: "Premium Linen Fabric",
      description: "High-quality sustainable linen fabric in various weights",
      image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
      tag: "New Arrival",
      tagColor: "bg-green-500"
    },
    {
      id: 3,
      name: "Eco-Friendly Packaging",
      description: "Biodegradable and recyclable packaging solutions",
      image: "https://images.unsplash.com/photo-1605640486608-2ebc507e1cca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=200&q=80",
      tag: "Eco-Friendly",
      tagColor: "bg-blue-500"
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium flex items-center">
          <Star className="h-5 w-5 mr-2 text-amber-500" />
          Featured Products
        </h2>
        <Button variant="ghost" size="sm" className="text-sm">
          View All <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {featuredProducts.map((product) => (
          <div key={product.id} className="relative rounded-lg overflow-hidden border group hover:shadow-md transition-all">
            <div className="relative aspect-video">
              <img 
                src={product.image} 
                alt={product.name} 
                className="object-cover w-full h-full" 
              />
              <div className="absolute top-2 left-2">
                <Badge className={cn("text-white", product.tagColor)}>
                  {product.tag}
                </Badge>
              </div>
            </div>
            
            <div className="p-4">
              <h3 className="font-medium mb-1">{product.name}</h3>
              <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Truck className="h-4 w-4 mr-1" />
                  <span>Fast shipping</span>
                </div>
                <Button size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <ShoppingCart className="h-4 w-4 mr-1" />
                  Details
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}