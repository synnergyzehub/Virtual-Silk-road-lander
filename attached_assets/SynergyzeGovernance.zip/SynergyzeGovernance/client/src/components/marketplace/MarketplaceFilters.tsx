import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { RefreshCw } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { Dispatch, SetStateAction } from "react";
import { Badge } from "@/components/ui/badge";

interface MarketplaceFiltersProps {
  priceRange: [number, number];
  setPriceRange: Dispatch<SetStateAction<[number, number]>>;
  inStockOnly: boolean;
  setInStockOnly: Dispatch<SetStateAction<boolean>>;
  activeCategory: string;
  setActiveCategory: Dispatch<SetStateAction<string>>;
}

export default function MarketplaceFilters({
  priceRange,
  setPriceRange,
  inStockOnly,
  setInStockOnly,
  activeCategory,
  setActiveCategory,
}: MarketplaceFiltersProps) {
  const handleResetFilters = () => {
    setPriceRange([0, 1000]);
    setInStockOnly(false);
    setActiveCategory("all");
  };

  return (
    <div className="space-y-6 marketplace-filters">
      <div className="flex items-center justify-between">
        <Button variant="ghost" className="text-sm p-0 h-auto" onClick={handleResetFilters}>
          <RefreshCw className="h-3 w-3 mr-1.5" />
          Reset All
        </Button>
        
        <div className="flex gap-1">
          {activeCategory !== "all" && <Badge variant="outline" className="text-xs">{activeCategory}</Badge>}
          {inStockOnly && <Badge variant="outline" className="text-xs">In Stock</Badge>}
        </div>
      </div>
      
      <Separator />
      
      <div className="space-y-5">
        <div>
          <Label htmlFor="price-filter" className="text-sm font-medium mb-3 block">
            Price Range (USD)
          </Label>
          <div className="px-1 mb-2">
            <Slider
              id="price-filter"
              defaultValue={[0, 1000]}
              max={1000}
              step={10}
              value={priceRange}
              onValueChange={(value) => setPriceRange(value as [number, number])}
            />
          </div>
          <div className="flex items-center justify-between mt-1 text-sm text-muted-foreground">
            <span>${priceRange[0]}</span>
            <span>${priceRange[1]}</span>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <Label htmlFor="in-stock" className="text-sm font-medium cursor-pointer">
              In stock only
            </Label>
            <Switch
              id="in-stock"
              checked={inStockOnly}
              onCheckedChange={setInStockOnly}
            />
          </div>
        </div>
        
        <Separator />

        <Accordion type="multiple" className="w-full space-y-2">
          <AccordionItem value="product-type" className="border-none">
            <AccordionTrigger className="text-sm font-medium py-2 hover:no-underline">
              Product Type
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pl-1">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="type-all"
                    name="product-type"
                    className="rounded-full"
                    checked={activeCategory === "all"}
                    onChange={() => setActiveCategory("all")}
                  />
                  <Label htmlFor="type-all" className="text-sm cursor-pointer">
                    All Products
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="type-apparel"
                    name="product-type"
                    className="rounded-full"
                    checked={activeCategory === "Apparel"}
                    onChange={() => setActiveCategory("Apparel")}
                  />
                  <Label htmlFor="type-apparel" className="text-sm cursor-pointer">
                    Apparel
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="type-fabric"
                    name="product-type"
                    className="rounded-full"
                    checked={activeCategory === "Fabric"}
                    onChange={() => setActiveCategory("Fabric")}
                  />
                  <Label htmlFor="type-fabric" className="text-sm cursor-pointer">
                    Fabric
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="type-accessories"
                    name="product-type"
                    className="rounded-full"
                    checked={activeCategory === "Accessories"}
                    onChange={() => setActiveCategory("Accessories")}
                  />
                  <Label htmlFor="type-accessories" className="text-sm cursor-pointer">
                    Accessories
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="type-packaging"
                    name="product-type"
                    className="rounded-full"
                    checked={activeCategory === "Packaging"}
                    onChange={() => setActiveCategory("Packaging")}
                  />
                  <Label htmlFor="type-packaging" className="text-sm cursor-pointer">
                    Packaging
                  </Label>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="material" className="border-none">
            <AccordionTrigger className="text-sm font-medium py-2 hover:no-underline">
              Material
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pl-1">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="material-cotton" className="rounded" />
                  <Label htmlFor="material-cotton" className="text-sm cursor-pointer">
                    Cotton
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="material-polyester" className="rounded" />
                  <Label htmlFor="material-polyester" className="text-sm cursor-pointer">
                    Polyester
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="material-linen" className="rounded" />
                  <Label htmlFor="material-linen" className="text-sm cursor-pointer">
                    Linen
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="material-wool" className="rounded" />
                  <Label htmlFor="material-wool" className="text-sm cursor-pointer">
                    Wool
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="material-silk" className="rounded" />
                  <Label htmlFor="material-silk" className="text-sm cursor-pointer">
                    Silk
                  </Label>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="minimum-order" className="border-none">
            <AccordionTrigger className="text-sm font-medium py-2 hover:no-underline">
              Minimum Order
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pl-1">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="moq-50" className="rounded" />
                  <Label htmlFor="moq-50" className="text-sm cursor-pointer">
                    Under 50 pcs
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="moq-100" className="rounded" />
                  <Label htmlFor="moq-100" className="text-sm cursor-pointer">
                    50 - 100 pcs
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="moq-300" className="rounded" />
                  <Label htmlFor="moq-300" className="text-sm cursor-pointer">
                    100 - 300 pcs
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="moq-500" className="rounded" />
                  <Label htmlFor="moq-500" className="text-sm cursor-pointer">
                    300 - 500 pcs
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="moq-over" className="rounded" />
                  <Label htmlFor="moq-over" className="text-sm cursor-pointer">
                    Over 500 pcs
                  </Label>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="lead-time" className="border-none">
            <AccordionTrigger className="text-sm font-medium py-2 hover:no-underline">
              Lead Time
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pl-1">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="lead-7" className="rounded" />
                  <Label htmlFor="lead-7" className="text-sm cursor-pointer">
                    Under 7 days
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="lead-14" className="rounded" />
                  <Label htmlFor="lead-14" className="text-sm cursor-pointer">
                    7-14 days
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="lead-30" className="rounded" />
                  <Label htmlFor="lead-30" className="text-sm cursor-pointer">
                    15-30 days
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="lead-60" className="rounded" />
                  <Label htmlFor="lead-60" className="text-sm cursor-pointer">
                    30-60 days
                  </Label>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      <div className="pt-2">
        <Button className="w-full">Apply Filters</Button>
      </div>
    </div>
  );
}