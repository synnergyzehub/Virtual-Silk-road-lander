import { useState, useEffect } from "react";
import { Bot, X, HelpCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useAiHelp } from "@/hooks/use-ai-help";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
}

interface ContextualHelpButtonProps {
  context?: string;
  suggestedQuestions?: string[];
}

export function ContextualHelpButton({ 
  context = "general", 
  suggestedQuestions = [] 
}: ContextualHelpButtonProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Hello! I'm your Synergyze AI assistant. How can I help you with your supply chain management today?",
      role: "assistant",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  // Default suggested questions based on context if none provided
  const defaultSuggestions: Record<string, string[]> = {
    general: [
      "How do I navigate between different modules?",
      "What are the key features of Synergyze?",
      "How can I track my inventory?",
    ],
    marketplace: [
      "How do I filter products by category?",
      "What information is needed to place an order?",
      "How do I track my marketplace orders?",
    ],
    buyingHouse: [
      "How do I submit a sample request?",
      "What's the process for production tracking?",
      "How do I review order status?",
    ],
    dashboard: [
      "How do I interpret the dashboard metrics?",
      "Where can I find historical data?",
      "How to export reports from the dashboard?",
    ],
  };

  const questions = suggestedQuestions.length > 0 
    ? suggestedQuestions 
    : (defaultSuggestions[context] || defaultSuggestions.general);

  // Generate a unique ID for messages
  const generateId = () => Math.random().toString(36).substring(2, 10);

  // Get the AI help hook
  const { getAiHelp, isLoading: aiLoading, error: aiError } = useAiHelp();
  
  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: generateId(),
      content,
      role: "user",
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    
    try {
      // Get previous messages in the format required by the API
      const previousMessages = messages
        .slice(-4) // Last 4 messages for context
        .map(msg => ({
          role: msg.role,
          content: msg.content
        }));
      
      // Call the AI help API
      const aiHelpResponse = await getAiHelp({
        query: content,
        context,
        previousMessages
      });
      
      // Create response message
      const aiResponse: Message = {
        id: generateId(),
        content: aiHelpResponse.response,
        role: "assistant",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiResponse]);
    } catch (error) {
      // Add error message if API call fails
      const errorResponse: Message = {
        id: generateId(),
        content: "I'm sorry, I encountered an error processing your request. Please try again later.",
        role: "assistant",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorResponse]);
      console.error("AI Help Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputValue);
  };

  const handleSuggestedQuestion = (question: string) => {
    handleSendMessage(question);
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          size="icon"
          variant="outline"
          className="rounded-full fixed bottom-6 right-6 h-12 w-12 shadow-lg z-[9999] bg-primary text-primary-foreground hover:bg-primary/90"
          aria-label="Help"
        >
          <HelpCircle className="h-6 w-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="sm:max-w-md w-[90vw] p-0 flex flex-col">
        <SheetHeader className="px-4 py-3 border-b">
          <div className="flex justify-between items-center">
            <SheetTitle className="flex items-center">
              <Bot className="mr-2 h-5 w-5" />
              AI Assistant
            </SheetTitle>
            <SheetClose asChild>
              <Button variant="ghost" size="icon">
                <X className="h-4 w-4" />
              </Button>
            </SheetClose>
          </div>
        </SheetHeader>
        
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg px-3 py-2 ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-lg px-4 py-2 bg-muted">
                  <Loader2 className="h-5 w-5 animate-spin" />
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {messages.length === 1 && questions.length > 0 && (
          <div className="px-4 py-3 border-t">
            <p className="text-sm font-medium mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {questions.map((question, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                  onClick={() => handleSuggestedQuestion(question)}
                >
                  {question}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        <div className="p-4 border-t mt-auto">
          <form onSubmit={handleSubmit} className="flex items-end gap-2">
            <Textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Type your question here..."
              className="min-h-[60px] resize-none flex-1"
            />
            <Button type="submit" disabled={isLoading || !inputValue.trim()}>
              Send
            </Button>
          </form>
        </div>
      </SheetContent>
    </Sheet>
  );
}