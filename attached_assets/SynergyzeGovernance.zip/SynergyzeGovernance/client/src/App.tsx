import { Switch, Route, Redirect, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { useAuth } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import DashboardPage from "@/pages/dashboard-page";
import BuyingHousePage from "@/pages/buying-house-page";
import MarketplacePage from "@/pages/marketplace-page";
import SynergyHubPage from "@/pages/synergyhub-page";
import LandingPage from "@/pages/landing-page";
import { ProtectedRoute } from "./lib/protected-route";
import { useEffect, useState } from "react";
import { TourGuide } from "@/components/onboarding/TourGuide";
import { TourButton } from "@/components/onboarding/TourButton";
import { ContextualHelpButton } from "@/components/help/ContextualHelpButton";

// Redirects /auth to the new /synergyhub route for backward compatibility
function AuthRedirect() {
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    setLocation("/synergyhub");
  }, [setLocation]);
  
  return null;
}

function PublicOrProtectedRoute({ component: Component, path, requiresAuth = true, ...rest }: any) {
  // Instead of using useAuth directly, we'll use Route to defer auth check to the component itself
  // This prevents the PublicOrProtectedRoute from requiring auth context
  const [location] = useLocation();
  
  return (
    <Route 
      path={path} 
      component={() => {
        try {
          // Only attempt to check auth if the component needs it and path matches
          if (requiresAuth) {
            const auth = useAuth();
            if (!auth?.user) {
              return <Redirect to="/synergyhub" />;
            }
          }
          return <Component {...rest} />;
        } catch (error) {
          // If auth context is not available, just render the component 
          // (for public routes like marketplace)
          return <Component {...rest} />;
        }
      }} 
    />
  );
}

function Router() {
  return (
    <Switch>
      {/* Public routes - Main entry points */}
      <Route path="/" component={LandingPage} />
      <Route path="/auth" component={AuthRedirect} />
      <Route path="/synergyhub" component={SynergyHubPage} />
      <PublicOrProtectedRoute path="/buying-house" component={BuyingHousePage} requiresAuth={false} /> {/* Woven Supply Marketplace */}
      <PublicOrProtectedRoute path="/marketplace" component={MarketplacePage} requiresAuth={false} /> {/* Commune Connect Network */}
      
      {/* Protected routes */}
      <ProtectedRoute path="/dashboard" component={DashboardPage} /> {/* Admin Dashboard - Requires Authentication */}
      
      {/* 404 route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [forceTourStart, setForceTourStart] = useState(false);
  const [location] = useLocation();
  const [helpContext, setHelpContext] = useState("general");
  
  // Update help context based on current route
  useEffect(() => {
    if (location.includes("marketplace")) {
      setHelpContext("marketplace");
    } else if (location.includes("buying-house")) {
      setHelpContext("buyingHouse");
    } else if (location.includes("dashboard")) {
      setHelpContext("dashboard");
    } else {
      setHelpContext("general");
    }
  }, [location]);
  
  // Adding suggested questions based on context
  const getSuggestedQuestions = () => {
    switch(helpContext) {
      case "marketplace":
        return [
          "How do I filter products by category?",
          "What information is needed to place an order?",
          "How do I track my marketplace orders?"
        ];
      case "buyingHouse":
        return [
          "How do I submit a sample request?",
          "What's the process for production tracking?",
          "How do I review order status?"
        ];
      case "dashboard":
        return [
          "How do I interpret the dashboard metrics?",
          "Where can I find historical data?",
          "How to export reports from the dashboard?"
        ];
      default:
        return [
          "How do I navigate between different modules?",
          "What are the key features of Synergyze?",
          "How can I track my inventory?"
        ];
    }
  };
  
  return (
    <>
      <Router />
      <TourGuide forceStart={forceTourStart} />
      <ContextualHelpButton 
        context={helpContext} 
        suggestedQuestions={getSuggestedQuestions()}
      />
      <Toaster />
    </>
  );
}

export default App;
