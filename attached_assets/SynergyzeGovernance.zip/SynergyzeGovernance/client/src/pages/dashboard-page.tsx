import { useAuth } from "@/hooks/use-auth";
import { HeaderNav } from "@/components/dashboard/HeaderNav";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { WovenSupplyView } from "@/components/dashboard/WovenSupplyView";
import { CommuneConnectView } from "@/components/dashboard/CommuneConnectView";
import { SynergyzeView } from "@/components/dashboard/SynergyzeView";
import { useState } from "react";

type DashboardView = "woven" | "commune" | "synergyze";

export default function DashboardPage() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState<DashboardView>("woven");

  return (
    <div className="min-h-screen bg-background dashboard-overview">
      <HeaderNav />
      <div className="flex">
        <Sidebar currentView={currentView} onViewChange={setCurrentView} />
        <main className="flex-1 p-6">
          <div className="quick-actions mb-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-card rounded-lg shadow p-4 text-center">
                <h3 className="font-medium">Quick Actions</h3>
                <p className="text-sm text-muted-foreground">Access frequently used functions</p>
              </div>
              <div className="bg-card rounded-lg shadow p-4 text-center">
                <h3 className="font-medium">Recent Activity</h3>
                <p className="text-sm text-muted-foreground">View your latest actions</p>
              </div>
              <div className="bg-card rounded-lg shadow p-4 text-center">
                <h3 className="font-medium">Notifications</h3>
                <p className="text-sm text-muted-foreground">Check important updates</p>
              </div>
            </div>
          </div>
          
          <div className="analytics-cards">
            {currentView === "woven" && <WovenSupplyView />}
            {currentView === "commune" && <CommuneConnectView />}
            {currentView === "synergyze" && <SynergyzeView />}
          </div>
        </main>
      </div>
    </div>
  );
}
