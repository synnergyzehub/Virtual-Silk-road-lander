import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { MoonIcon, SunIcon } from "lucide-react";

export default function LandingPage() {
  const [, setLocation] = useLocation();
  
  // Use try/catch to handle case where auth provider might not be available
  let user = null;
  try {
    const auth = useAuth();
    user = auth.user;
  } catch (e) {
    // Auth provider not available, continue without user info
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto py-4 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img src="/generated-icon.png" alt="Synergyze Logo" className="h-10 w-10 mr-2" />
              <span className="text-xl font-bold">SYNERGYZE</span>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-sm font-medium hover:text-primary">Home</a>
              <a href="#" className="text-sm font-medium hover:text-primary">About Synergyze</a>
              <a href="#" className="text-sm font-medium hover:text-primary">Synergy Platform</a>
              <a href="#" className="text-sm font-medium hover:text-primary">Newsroom</a>
              <a href="#" className="text-sm font-medium hover:text-primary">Contact Us</a>
            </nav>
            
            {user ? (
              <Button onClick={() => setLocation("/dashboard")}>
                Dashboard
              </Button>
            ) : (
              <Button onClick={() => setLocation("/synergyhub")}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>
      
      <main>
        <section className="py-20 px-4">
          <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl font-bold leading-tight mb-6">
                Transforming Business Strategy with Innovative SCM Solutions
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Unlock your brand's potential with our technology-driven SCM platform, designed to
                streamline operations and enhance business strategies for sustainable growth and
                efficiency.
              </p>
              <Button size="lg" onClick={() => setLocation("/synergyhub")}>
                Get Started
              </Button>
            </div>
            
            <div className="relative">
              <div className="grid grid-cols-6 gap-1 absolute right-0 top-0 opacity-20">
                {Array(36).fill(0).map((_, i) => (
                  <div key={i} className="w-2 h-2 bg-primary rounded-full"></div>
                ))}
              </div>
              
              <img
                src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="Business professional using SCM platform"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </section>
        
        <section className="py-8">
          <div className="container mx-auto px-4">
            <h2 className="text-lg font-medium mb-4 text-center">Trusted By</h2>
            <div className="flex justify-center items-center gap-12">
              <img 
                src="https://upload.wikimedia.org/wikipedia/en/6/65/Voi_Jeans_Logo.jpg" 
                alt="Voi Jeans" 
                className="h-8 grayscale hover:grayscale-0 transition-all duration-300"
              />
              <div className="bg-black text-white px-3 py-1 font-bold text-sm grayscale hover:grayscale-0 transition-all duration-300">
                KILLER
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}