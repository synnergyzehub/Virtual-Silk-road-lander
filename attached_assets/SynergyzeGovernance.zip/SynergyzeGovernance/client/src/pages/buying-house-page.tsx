import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BuyingHouseHeader from "@/components/buying-house/BuyingHouseHeader";
import SampleRequestForm from "@/components/buying-house/SampleRequestForm";
import SampleStatusTracker from "@/components/buying-house/SampleStatusTracker";
import ProductionOrderTracker from "@/components/buying-house/ProductionOrderTracker";
import ProductCatalog from "@/components/buying-house/ProductCatalog";
import BuyerFAQ from "@/components/buying-house/BuyerFAQ";

export default function BuyingHousePage() {
  const [activeTab, setActiveTab] = useState("catalog");

  return (
    <div className="min-h-screen bg-background">
      <BuyingHouseHeader />
      
      <main className="container mx-auto py-6 px-4">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Welcome to Buying House Forum</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Connect with our buying house for apparel manufacturing, sample development, and production order tracking.
              Use the tools below to manage your requests and orders.
            </p>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="catalog">Product Catalog</TabsTrigger>
            <TabsTrigger value="sample-request">Request Sample</TabsTrigger>
            <TabsTrigger value="sample-status">Sample Status</TabsTrigger>
            <TabsTrigger value="order-tracking">Order Tracking</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
          </TabsList>
          
          <TabsContent value="catalog" className="mt-6">
            <ProductCatalog />
          </TabsContent>
          
          <TabsContent value="sample-request" className="mt-6">
            <SampleRequestForm />
          </TabsContent>
          
          <TabsContent value="sample-status" className="mt-6">
            <SampleStatusTracker />
          </TabsContent>
          
          <TabsContent value="order-tracking" className="mt-6">
            <ProductionOrderTracker />
          </TabsContent>
          
          <TabsContent value="faq" className="mt-6">
            <BuyerFAQ />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}