import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { extendedInsertUserSchema, insertUserSchema, OrganizationType } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Package, Shield, AlertCircle, Store, Factory, CreditCard, LogOut, ChevronRight, Building, User } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const loginFormSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerFormSchema = extendedInsertUserSchema.extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  organizationType: z.enum(["buyer", "manufacturer", "distributor", "retailer", "vendor"]).optional(),
  companyName: z.string().optional(),
  gdprConsent: z.boolean().refine(val => val, {
    message: "You must accept the terms and privacy policy",
  })
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginFormSchema>;
type RegisterFormValues = z.infer<typeof registerFormSchema>;

export default function SynergyHubPage() {
  const [authTab, setAuthTab] = useState("login");
  const [, setLocation] = useLocation();
  // Try to get auth context, or use fallback values if it fails
  let user = null;
  let loginMutation = { mutate: () => {}, isPending: false } as any;
  let registerMutation = { mutate: () => {}, isPending: false } as any;
  let logoutMutation = { mutate: () => {} } as any;
  let isLoading = false;
  let error = null;
  
  try {
    const auth = useAuth();
    user = auth?.user || null;
    loginMutation = auth?.loginMutation;
    registerMutation = auth?.registerMutation;
    logoutMutation = auth?.logoutMutation;
    isLoading = auth?.isLoading || false;
    error = auth?.error || null;
  } catch (e) {
    console.log("Auth context not available");
  }
  
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerFormSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      role: "supply_chain_manager",
      jobTitle: "",
      organizationType: undefined,
      companyName: "",
      gdprConsent: false,
    },
  });
  
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        setLocation("/dashboard");
      }
    });
  };
  
  const onRegisterSubmit = (data: RegisterFormValues) => {
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData, {
      onSuccess: () => {
        setLocation("/dashboard");
      }
    });
  };

  if (user) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-primary text-primary-foreground py-4">
          <div className="container mx-auto flex items-center justify-between px-4">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8" />
              <span className="text-xl font-bold">SynergyHub</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-primary-foreground">
                  {user.role === 'admin' ? 'Administrator' : user.role.split('_').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1)
                  ).join(' ')}
                </Badge>
                <span className="text-sm font-medium">
                  {user.role === 'admin' ? `${user.username} (Admin)` : user.username}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="border-primary-foreground"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </header>

        <main className="container mx-auto py-8 px-4">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold mb-2">Welcome to SynergyHub</h1>
            <p className="text-muted-foreground">Your central access point to all supply chain management platforms</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <Card className="overflow-hidden">
              <div className="h-2 bg-blue-500" />
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-2 rounded-full bg-blue-100">
                  <Factory className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <CardTitle>Woven Supply</CardTitle>
                  <CardDescription>Supply chain management</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Manage inventory, vendors, purchase orders, and production tracking.
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Purchase Orders</span>
                    <Badge variant="outline">12 Active</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Inventory Items</span>
                    <Badge variant="outline">256 Items</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation("/dashboard")}>
                  Access Dashboard
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden">
              <div className="h-2 bg-green-500" />
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-2 rounded-full bg-green-100">
                  <Store className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <CardTitle>Commune Connect</CardTitle>
                  <CardDescription>Retail management</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Manage retail orders, customer relationships, and store performance.
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Retail Orders</span>
                    <Badge variant="outline">35 Pending</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Store Locations</span>
                    <Badge variant="outline">8 Stores</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation("/dashboard")}>
                  Access Dashboard
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden">
              <div className="h-2 bg-purple-500" />
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-2 rounded-full bg-purple-100">
                  <CreditCard className="h-6 w-6 text-purple-500" />
                </div>
                <div>
                  <CardTitle>Synergyze Finance</CardTitle>
                  <CardDescription>Financial management</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Track invoices, payments, and financial performance metrics.
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Pending Invoices</span>
                    <Badge variant="outline">18 Invoices</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Revenue (MTD)</span>
                    <Badge variant="outline">$125,450</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation("/dashboard")}>
                  Access Dashboard
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Public Services</CardTitle>
                <CardDescription>Access public-facing platforms</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 rounded-lg border hover:bg-accent cursor-pointer" onClick={() => setLocation("/marketplace")}>
                  <div className="flex items-center gap-3">
                    <Package className="h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-medium">Marketplace</h3>
                      <p className="text-sm text-muted-foreground">Browse and purchase products</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
                
                <div className="flex justify-between items-center p-3 rounded-lg border hover:bg-accent cursor-pointer" onClick={() => setLocation("/buying-house")}>
                  <div className="flex items-center gap-3">
                    <Factory className="h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-medium">Buying House</h3>
                      <p className="text-sm text-muted-foreground">Request samples and manage production</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Your Account</CardTitle>
                <CardDescription>Manage your profile and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 rounded-lg border">
                    <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-medium text-lg">
                      {user.username.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-medium">{user.username}</h3>
                      <p className="text-sm text-muted-foreground capitalize">{user.role.replace('_', ' ')}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" className="w-full">Edit Profile</Button>
                    <Button variant="outline" className="w-full" onClick={() => logoutMutation.mutate()}>Logout</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="flex items-center mb-8">
        <Package className="h-10 w-10 mr-3 text-primary" />
        <h1 className="text-3xl font-bold">SynergyHub</h1>
      </div>
      
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">
            Welcome to SynergyHub
          </CardTitle>
          <CardDescription className="text-center">
            The integrated management platform for supply chain solutions.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error.message || "Authentication failed. Please try again."}
              </AlertDescription>
            </Alert>
          )}
          
          <Tabs value={authTab} onValueChange={setAuthTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Log In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Enter your password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="remember" />
                    <label
                      htmlFor="remember"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Remember me
                    </label>
                  </div>
                  
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Logging in..." : "Log in"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="register">
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Create a username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Create a password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Confirm your password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-2 pb-1">
                    <Separator />
                    <h3 className="text-sm font-medium mt-3 mb-2 flex items-center">
                      <User className="h-4 w-4 mr-2" />
                      Personal Information
                    </h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter first name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter last name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter email address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="pt-2 pb-1">
                    <Separator />
                    <h3 className="text-sm font-medium mt-3 mb-2 flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Organization Details
                    </h3>
                  </div>
                  
                  <FormField
                    control={registerForm.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter company name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="organizationType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Organization Type</FormLabel>
                          <FormControl>
                            <select
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                              {...field}
                              value={field.value || ""}
                              onChange={(e) => field.onChange(e.target.value || undefined)}
                            >
                              <option value="">Select Type</option>
                              <option value="buyer">Buyer</option>
                              <option value="manufacturer">Manufacturer</option>
                              <option value="distributor">Distributor</option>
                              <option value="retailer">Retailer</option>
                              <option value="vendor">Vendor</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="jobTitle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Job Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter job title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={registerForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>System Role</FormLabel>
                        <FormControl>
                          <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            {...field}
                          >
                            <option value="supply_chain_manager">Supply Chain Manager</option>
                            <option value="retail_manager">Retail Manager</option>
                            <option value="finance_specialist">Finance Specialist</option>
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="gdprConsent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-2 rounded-md border">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the Terms of Service and Privacy Policy
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Registering..." : "Register"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col items-center">
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Shield className="h-3 w-3" />
            <span>Secure authentication</span>
          </div>
          
          <Separator className="my-4" />
          
          <div className="flex flex-col items-center text-center text-sm text-muted-foreground">
            <p>SynergyHub provides integrated access to:</p>
            <div className="flex space-x-4 mt-2">
              <span className="font-medium">Woven Supply</span>
              <span className="font-medium">Commune Connect</span>
              <span className="font-medium">Synergyze Finance</span>
            </div>
          </div>
        </CardFooter>
      </Card>
      
      <div className="mt-8 flex items-center justify-center gap-4">
        <Button variant="outline" onClick={() => setLocation("/marketplace")}>
          Visit Marketplace
        </Button>
        <Button variant="outline" onClick={() => setLocation("/buying-house")}>
          Visit Buying House
        </Button>
      </div>
    </div>
  );
}