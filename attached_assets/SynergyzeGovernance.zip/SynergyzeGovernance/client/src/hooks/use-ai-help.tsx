import { useState } from 'react';

interface AiHelpRequest {
  query: string;
  context: string;
  previousMessages?: Array<{
    role: "user" | "assistant";
    content: string;
  }>;
}

interface AiHelpResponse {
  response: string;
  suggestedFollowUp?: string[];
}

export function useAiHelp() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const getAiHelp = async (request: AiHelpRequest): Promise<AiHelpResponse> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/help', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });
      
      if (!response.ok) {
        throw new Error('Failed to get AI help: ' + response.statusText);
      }
      
      const data = await response.json();
      return data as AiHelpResponse;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to get AI help'));
      return {
        response: "I'm sorry, I encountered an error while processing your request. Please try again later.",
        suggestedFollowUp: ["How do I navigate the system?", "What are the main features?"]
      };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    getAiHelp,
    isLoading,
    error
  };
}