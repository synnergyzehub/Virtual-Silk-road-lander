import React, { createContext, ReactNode, useContext, useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useLocalStorage } from "@/hooks/use-local-storage";

type TourContextType = {
  currentPage: string;
  forceTourStart: () => void;
  resetAllTours: () => void;
};

const TourContext = createContext<TourContextType | null>(null);

export function TourProvider({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [forceStart, setForceStart] = useState(false);
  const [completedTours, setCompletedTours] = useLocalStorage<string[]>("completed-tours", []);
  
  // Extract the current page from the location
  const currentPage = location.startsWith("/") ? location.substring(1) : location;
  
  // Reset the force start state when location changes
  useEffect(() => {
    setForceStart(false);
  }, [location]);
  
  const forceTourStart = () => {
    setForceStart(true);
  };
  
  const resetAllTours = () => {
    setCompletedTours([]);
  };
  
  return (
    <TourContext.Provider
      value={{
        currentPage,
        forceTourStart,
        resetAllTours,
      }}
    >
      {children}
    </TourContext.Provider>
  );
}

export function useTour() {
  const context = useContext(TourContext);
  
  if (!context) {
    throw new Error("useTour must be used within a TourProvider");
  }
  
  return context;
}