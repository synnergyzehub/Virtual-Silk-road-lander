import { 
  users, 
  organizations,
  type User, 
  type InsertUser, 
  type AuditLog, 
  type InsertAuditLog, 
  type Organization,
  type OrganizationType, 
  type ExtendedInsertUser,
  type InsertOrganization
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { hashPassword } from "./crypto";
import { log } from "./vite";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createExtendedUser(user: ExtendedInsertUser): Promise<User>;
  updateUserLastLogin(userId: number): Promise<void>;
  
  // Organization methods
  getOrganization(id: number): Promise<Organization | undefined>;
  createOrganization(organization: InsertOrganization): Promise<Organization>;
  
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(userId?: number): Promise<AuditLog[]>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private organizations: Map<number, Organization>;
  private auditLogs: Map<number, AuditLog>;
  currentId: number;
  currentOrgId: number;
  currentAuditLogId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.organizations = new Map();
    this.auditLogs = new Map();
    this.currentId = 1;
    this.currentOrgId = 1;
    this.currentAuditLogId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  private async initializeAdminUser() {
    const hashedPassword = await hashPassword("1234");
    
    // Initialize admin user
    const existingAdmin = await this.getUserByUsername("Faiz@voijeans.in");
    if (!existingAdmin) {
      await this.createUser({
        username: "Faiz@voijeans.in",
        password: hashedPassword,
        role: "admin"
      });
    }
    
    // Initialize test users for different roles
    const testUsers = [
      { username: "supply@test.com", role: "supply_chain_manager" },
      { username: "retail@test.com", role: "retail_manager" },
      { username: "finance@test.com", role: "finance_specialist" }
    ];
    
    for (const testUser of testUsers) {
      const existingUser = await this.getUserByUsername(testUser.username);
      if (!existingUser) {
        await this.createUser({
          username: testUser.username,
          password: hashedPassword, // Using same password "1234" for all test users
          role: testUser.role
        });
      }
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async updateUserLastLogin(userId: number): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      user.lastLogin = new Date();
      this.users.set(userId, user);
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      lastLogin: now
    };
    this.users.set(id, user);
    log(`Created user: ${user.username} with role ${user.role}`, 'storage');
    return user;
  }

  async createAuditLog(insertLog: InsertAuditLog): Promise<AuditLog> {
    const id = this.currentAuditLogId++;
    const auditLog: AuditLog = {
      ...insertLog,
      id,
      timestamp: new Date()
    };
    this.auditLogs.set(id, auditLog);
    return auditLog;
  }

  async getAuditLogs(userId?: number): Promise<AuditLog[]> {
    const logs = Array.from(this.auditLogs.values());
    return userId 
      ? logs.filter(log => log.userId === userId)
      : logs;
  }
}

// Create storage instance and initialize admin user
export const storage = new MemStorage();
storage.initializeAdminUser().catch(console.error);