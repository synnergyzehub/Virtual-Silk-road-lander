import { Router, Request, Response } from "express";
import { z } from "zod";

// Define types for AI assistance
export interface AiHelpRequest {
  query: string;
  context: string;
  previousMessages?: Array<{
    role: "user" | "assistant";
    content: string;
  }>;
}

export interface AiHelpResponse {
  response: string;
  suggestedFollowUp?: string[];
}

// Zod schema for validation
const aiHelpRequestSchema = z.object({
  query: z.string().min(1),
  context: z.string().default("general"),
  previousMessages: z.array(
    z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string(),
    })
  ).optional(),
});

// Mock AI response generation based on context and query
function generateAiResponse(request: AiHelpRequest): AiHelpResponse {
  const { query, context } = request;
  const lowerQuery = query.toLowerCase();
  
  // Contextual responses for different parts of the application
  const contextualResponses: Record<string, Record<string, string>> = {
    marketplace: {
      "filter": "You can filter products by using the filter panel on the left side of the marketplace. Select categories, adjust price ranges, or toggle 'In stock only' to refine your search results.",
      "order": "To place an order, first select the products you want, then click 'Add to Cart'. You can review your cart and proceed to checkout where you'll need to provide shipping information and payment details.",
      "track": "Order tracking is available in your account dashboard under 'My Orders'. Each order will show its current status, estimated delivery date, and tracking information once shipped.",
      "default": "The marketplace allows you to browse products from multiple vendors, compare prices, and place orders directly through our platform. You can filter products, save favorites, and track your order history."
    },
    buyingHouse: {
      "sample": "To submit a sample request, navigate to the 'Sample Requests' section in the Buying House area, fill out the required product details, quantity, and specifications, then submit the form. Our team will review and respond within 48 hours.",
      "production": "Production tracking is available in the 'Production Orders' tab. You can see real-time updates on each stage from pattern-making to quality checking and ready-for-shipment status.",
      "status": "Order status can be checked in 'Order Tracking'. This provides a comprehensive view of all your orders and their current stage in the production or delivery process.",
      "default": "The Buying House module connects you directly with manufacturers. You can request samples, place production orders, track manufacturing progress, and manage specifications all in one place."
    },
    dashboard: {
      "metrics": "Dashboard metrics provide a real-time overview of your supply chain performance. Green indicators show healthy metrics, while yellow or red indicators highlight areas that may need attention.",
      "historical": "Historical data can be accessed by clicking on any chart and selecting the 'View History' option. You can also use the date range selector at the top of the dashboard to view past periods.",
      "export": "To export reports, look for the download icon in the top-right corner of each dashboard widget. You can export data in CSV, Excel, or PDF formats for further analysis or sharing.",
      "default": "The dashboard provides a centralized view of all your supply chain operations. Key metrics, alerts, and performance indicators help you make informed decisions quickly."
    },
    general: {
      "navigate": "You can navigate between different modules using the main sidebar menu on the left. For mobile devices, access the menu by clicking the hamburger icon in the top-left corner.",
      "features": "Key features of Synergyze include inventory management, order processing, vendor relationship management, production tracking, compliance monitoring, and comprehensive analytics.",
      "inventory": "Inventory tracking is available in the 'Inventory' module. You can view stock levels, set up alerts for low inventory, track movement history, and generate inventory reports.",
      "default": "Synergyze is an integrated supply chain management platform that connects all aspects of your operations from sourcing to delivery. If you have specific questions about any feature, please ask!"
    }
  };
  
  // Suggested follow-up questions based on context
  const followUpSuggestions: Record<string, string[]> = {
    marketplace: [
      "How do I contact a vendor directly?",
      "Can I save products for later?",
      "What payment methods are supported?"
    ],
    buyingHouse: [
      "How long does sample production typically take?",
      "Can I modify an order after it's submitted?",
      "What file formats do you accept for technical designs?"
    ],
    dashboard: [
      "How often is the dashboard data updated?",
      "Can I customize my dashboard view?",
      "How do I set up alerts for specific metrics?"
    ],
    general: [
      "How do I update my account information?",
      "Is there a mobile app available?",
      "How can I contact customer support?"
    ]
  };

  // Get the appropriate context responses or fallback to general
  const contextResponses = contextualResponses[context] || contextualResponses.general;
  
  // Determine the response based on keywords in the query
  let response = contextResponses.default;
  for (const [keyword, keywordResponse] of Object.entries(contextResponses)) {
    if (keyword !== "default" && lowerQuery.includes(keyword)) {
      response = keywordResponse;
      break;
    }
  }
  
  return {
    response,
    suggestedFollowUp: followUpSuggestions[context] || followUpSuggestions.general
  };
}

// Create and export router
export function createAiHelpRouter(): Router {
  const router = Router();
  
  // Endpoint to get AI help
  router.post("/", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = aiHelpRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({
          error: "Invalid request",
          details: validationResult.error.format()
        });
      }
      
      const aiRequest: AiHelpRequest = validationResult.data;
      
      // Generate AI response
      const aiResponse = generateAiResponse(aiRequest);
      
      // Add an artificial delay to simulate processing
      setTimeout(() => {
        res.status(200).json(aiResponse);
      }, 800);
      
    } catch (error) {
      console.error("AI Help Error:", error);
      res.status(500).json({
        error: "Failed to process AI help request",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  return router;
}