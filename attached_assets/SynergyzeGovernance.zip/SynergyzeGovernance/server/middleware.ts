import { Request, Response, NextFunction } from "express";
import { Role, rolePermissions } from "@shared/schema";
import { storage } from "./storage";
import { log } from "./vite";

export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const userRole = req.user?.role as Role;
    const permissions = rolePermissions[userRole];

    if (permissions.includes("all") || permissions.includes(permission)) {
      next();
    } else {
      log(`Permission denied: ${req.user?.username} attempted to access ${permission}`, 'auth');
      return res.status(403).json({ message: "Permission denied" });
    }
  };
}

export async function auditLog(
  req: Request,
  action: string,
  entityType: string,
  entityId: string,
  details?: string
) {
  try {
    await storage.createAuditLog({
      userId: req.user?.id,
      action,
      entityType,
      entityId,
      details: details || JSON.stringify(req.body),
    });
    log(`Audit log created: ${action} on ${entityType} by ${req.user?.username}`, 'audit');
  } catch (error) {
    log(`Error creating audit log: ${error}`, 'audit');
  }
}

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  log(`Error: ${status} - ${message}`, 'error');
  
  // Don't expose internal error details in production
  const response = process.env.NODE_ENV === "production" 
    ? { message: status === 500 ? "Internal Server Error" : message }
    : { message, stack: err.stack };

  res.status(status).json(response);
}
