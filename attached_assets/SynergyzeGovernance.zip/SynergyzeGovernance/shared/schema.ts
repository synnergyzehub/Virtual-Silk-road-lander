import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export type Role = 
  // Admin and Management Roles
  | "admin" 
  | "supply_chain_manager" 
  | "retail_manager" 
  | "finance_specialist"
  // Supply Chain Entity Roles
  | "buyer" 
  | "manufacturer" 
  | "distributor" 
  | "retailer" 
  | "vendor"
  // Sub-roles within Organizations
  | "buyer_purchasing_agent"
  | "buyer_quality_control"
  | "manufacturer_production_manager"
  | "manufacturer_quality_manager"
  | "distributor_logistics_manager"
  | "distributor_inventory_manager"
  | "retailer_store_manager"
  | "retailer_purchasing_manager"
  | "vendor_account_manager"
  | "vendor_catalog_manager";

// Role permissions mapping
export const rolePermissions = {
  // Admin/Management Roles
  admin: ["all"],
  supply_chain_manager: ["inventory.read", "inventory.write", "orders.read", "orders.write", "vendors.read", "vendors.write"],
  retail_manager: ["inventory.read", "orders.read", "orders.write", "retail.read", "retail.write"],
  finance_specialist: ["transactions.read", "transactions.write", "reports.read", "billing.read", "billing.write"],
  
  // Supply Chain Entity Roles
  buyer: ["samples.read", "samples.write", "orders.read", "orders.write", "vendors.read"],
  manufacturer: ["production.read", "production.write", "inventory.read", "inventory.write", "quality.read", "quality.write"],
  distributor: ["inventory.read", "inventory.write", "orders.read", "shipments.read", "shipments.write"],
  retailer: ["inventory.read", "orders.read", "orders.write", "retail.read", "retail.write"],
  vendor: ["catalog.read", "catalog.write", "orders.read", "pricing.read", "pricing.write"],
  
  // Sub-roles with limited permissions
  buyer_purchasing_agent: ["samples.read", "orders.read", "orders.write", "vendors.read"],
  buyer_quality_control: ["samples.read", "samples.write", "quality.read", "quality.write"],
  manufacturer_production_manager: ["production.read", "production.write", "inventory.read"],
  manufacturer_quality_manager: ["quality.read", "quality.write", "production.read"],
  distributor_logistics_manager: ["shipments.read", "shipments.write", "inventory.read"],
  distributor_inventory_manager: ["inventory.read", "inventory.write"],
  retailer_store_manager: ["retail.read", "retail.write", "inventory.read"],
  retailer_purchasing_manager: ["orders.read", "orders.write", "inventory.read"],
  vendor_account_manager: ["orders.read", "orders.write", "customer.read"],
  vendor_catalog_manager: ["catalog.read", "catalog.write", "pricing.read", "pricing.write"]
} as const;

export type Permission = keyof typeof rolePermissions;

// Organization type
export type OrganizationType = "buyer" | "manufacturer" | "distributor" | "retailer" | "vendor";

// Organization table
export const organizations = pgTable("organizations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().$type<OrganizationType>(),
  code: text("code").notNull().unique(),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  country: text("country"),
  postalCode: text("postal_code"),
  taxId: text("tax_id"),
  status: text("status").notNull().default("active"),
  verificationStatus: text("verification_status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Extended user table with organization relationship
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().$type<Role>(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  jobTitle: text("job_title"),
  email: text("email"),
  phone: text("phone"),
  organizationId: integer("organization_id").references(() => organizations.id),
  // For organizations with multiple departments
  department: text("department"),
  // For special permissions or restrictions
  accessLevel: integer("access_level").default(1),
  isActive: boolean("is_active").default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedBy: integer("updated_by"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit log schema
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Add gdprConsent to the insertUserSchema
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
}).extend({
  role: z.enum([
    // Admin and Management Roles
    "admin", "supply_chain_manager", "retail_manager", "finance_specialist",
    // Supply Chain Entity Roles
    "buyer", "manufacturer", "distributor", "retailer", "vendor",
    // Sub-roles within Organizations
    "buyer_purchasing_agent", "buyer_quality_control",
    "manufacturer_production_manager", "manufacturer_quality_manager",
    "distributor_logistics_manager", "distributor_inventory_manager",
    "retailer_store_manager", "retailer_purchasing_manager",
    "vendor_account_manager", "vendor_catalog_manager"
  ]),
  gdprConsent: z.boolean({
    required_error: "You must accept the terms to continue",
  }),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// Purchase Order Status
export type POStatus = "draft" | "pending_approval" | "approved" | "rejected" | "completed";

// Order Status
export type OrderStatus = "pending" | "processing" | "shipped" | "delivered" | "cancelled";

// Inventory Transaction Type
export type TransactionType = "receive" | "transfer" | "adjust" | "dispatch";

export type ConsentStatus = "granted" | "withdrawn" | "expired";
export type DataProcessingPurposeType =
  | "essential"
  | "analytics"
  | "marketing"
  | "third_party_sharing"
  | "profiling";

export type SampleStatus = "pending" | "approved" | "rejected" | "in_development";
export type ProductionStage = "pattern" | "sampling" | "bulk_production" | "quality_check" | "ready_for_shipment";
export type QuotationStatus = "draft" | "sent" | "accepted" | "rejected";

// Purchase Orders
export const purchaseOrders = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  vendorId: integer("vendor_id").notNull(),
  status: text("status").notNull().$type<POStatus>(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  createdBy: integer("created_by").references(() => users.id),
  approvedBy: integer("approved_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  items: jsonb("items").notNull(),
  notes: text("notes"),
});

// Vendors
export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  contactPerson: text("contact_person"),
  email: text("email"),
  phone: text("phone"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Inventory
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  productCode: text("product_code").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull().default(0),
  reorderPoint: integer("reorder_point"),
  warehouseId: integer("warehouse_id").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Inventory Transactions
export const inventoryTransactions = pgTable("inventory_transactions", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => inventory.id),
  type: text("type").notNull().$type<TransactionType>(),
  quantity: integer("quantity").notNull(),
  fromWarehouse: integer("from_warehouse"),
  toWarehouse: integer("to_warehouse"),
  referenceId: text("reference_id"),
  referenceType: text("reference_type"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Retail Orders
export const retailOrders = pgTable("retail_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  storeId: integer("store_id").notNull(),
  status: text("status").notNull().$type<OrderStatus>(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  items: jsonb("items").notNull(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const privacyPolicies = pgTable("privacy_policies", {
  id: serial("id").primaryKey(),
  version: text("version").notNull(),
  content: text("content").notNull(),
  effectiveDate: timestamp("effective_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dataProcessingPurposes = pgTable("data_processing_purposes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().$type<DataProcessingPurposeType>(),
  description: text("description").notNull(),
  isRequired: boolean("is_required").notNull().default(false),
  active: boolean("active").notNull().default(true),
});

export const userConsents = pgTable("user_consents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  purposeId: integer("purpose_id").references(() => dataProcessingPurposes.id),
  status: text("status").notNull().$type<ConsentStatus>(),
  policyVersion: text("policy_version").notNull(),
  ipAddress: text("ip_address"),
  consentedAt: timestamp("consented_at").notNull(),
  withdrawnAt: timestamp("withdrawn_at"),
  expiresAt: timestamp("expires_at"),
});

export const samples = pgTable("samples", {
  id: serial("id").primaryKey(),
  sampleNumber: text("sample_number").notNull().unique(),
  buyerId: integer("buyer_id").notNull(),
  productName: text("product_name").notNull(),
  category: text("category").notNull(),
  specifications: jsonb("specifications").notNull(),
  status: text("status").notNull().$type<SampleStatus>(),
  developmentNotes: text("development_notes"),
  createdBy: integer("created_by").references(() => users.id),
  approvedBy: integer("approved_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const costSheets = pgTable("cost_sheets", {
  id: serial("id").primaryKey(),
  quotationNumber: text("quotation_number").notNull().unique(),
  sampleId: integer("sample_id").references(() => samples.id),
  buyerId: integer("buyer_id").notNull(),
  materialCosts: jsonb("material_costs").notNull(),
  labourCosts: jsonb("labour_costs").notNull(),
  overheadCosts: decimal("overhead_costs", { precision: 10, scale: 2 }).notNull(),
  profit: decimal("profit", { precision: 10, scale: 2 }).notNull(),
  totalCost: decimal("total_cost", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().$type<QuotationStatus>(),
  validUntil: timestamp("valid_until").notNull(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const productionOrders = pgTable("production_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  buyerId: integer("buyer_id").notNull(),
  sampleId: integer("sample_id").references(() => samples.id),
  quotationId: integer("quotation_id").references(() => costSheets.id),
  quantity: integer("quantity").notNull(),
  deliveryDate: timestamp("delivery_date").notNull(),
  currentStage: text("current_stage").notNull().$type<ProductionStage>(),
  stageUpdates: jsonb("stage_updates").notNull(),
  qualityReports: jsonb("quality_reports"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// We need to add specific tables for different organization types

// Buyer organization details
export const buyerProfiles = pgTable("buyer_profiles", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  industryType: text("industry_type"),
  averageOrderValue: decimal("average_order_value", { precision: 10, scale: 2 }),
  preferredCategories: jsonb("preferred_categories"),
  paymentTerms: text("payment_terms"),
  shippingPreferences: jsonb("shipping_preferences"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Manufacturer organization details
export const manufacturerProfiles = pgTable("manufacturer_profiles", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  factoryLocations: jsonb("factory_locations"),
  productionCapacity: jsonb("production_capacity"),
  certifications: jsonb("certifications"),
  specializations: jsonb("specializations"),
  minimumOrderQuantity: integer("minimum_order_quantity"),
  leadTime: text("lead_time"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Distributor organization details
export const distributorProfiles = pgTable("distributor_profiles", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  coverageAreas: jsonb("coverage_areas"),
  warehouseLocations: jsonb("warehouse_locations"),
  transportationCapacity: jsonb("transportation_capacity"),
  specializedServices: jsonb("specialized_services"),
  distributionChannels: jsonb("distribution_channels"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Retailer organization details
export const retailerProfiles = pgTable("retailer_profiles", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  storeCount: integer("store_count"),
  storeLocations: jsonb("store_locations"),
  targetMarket: text("target_market"),
  salesChannels: jsonb("sales_channels"),
  averageMonthlyOrders: integer("average_monthly_orders"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Vendor organization details
export const vendorProfiles = pgTable("vendor_profiles", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  materialTypes: jsonb("material_types"),
  supplierLocations: jsonb("supplier_locations"),
  certifications: jsonb("certifications"),
  minimumOrderValue: decimal("minimum_order_value", { precision: 10, scale: 2 }),
  averageLeadTime: text("average_lead_time"),
  paymentTerms: jsonb("payment_terms"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business relationship type
export type RelationshipType = 
  | "buyer_manufacturer" 
  | "manufacturer_distributor" 
  | "distributor_retailer" 
  | "manufacturer_retailer" 
  | "buyer_vendor" 
  | "manufacturer_vendor";

export type RelationshipStatus = "pending" | "active" | "paused" | "terminated";

// Table to track business relationships between organizations
export const businessRelationships = pgTable("business_relationships", {
  id: serial("id").primaryKey(),
  type: text("type").notNull().$type<RelationshipType>(),
  sourceOrgId: integer("source_org_id").references(() => organizations.id).notNull(),
  targetOrgId: integer("target_org_id").references(() => organizations.id).notNull(),
  status: text("status").notNull().$type<RelationshipStatus>().default("pending"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  contractRef: text("contract_ref"),
  terms: jsonb("terms"),
  creditLimit: decimal("credit_limit", { precision: 10, scale: 2 }),
  paymentTerms: text("payment_terms"),
  discountRate: decimal("discount_rate", { precision: 5, scale: 2 }),
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas for organizations and profiles
export const insertOrganizationSchema = createInsertSchema(organizations).extend({
  type: z.enum(["buyer", "manufacturer", "distributor", "retailer", "vendor"])
});

export const insertBuyerProfileSchema = createInsertSchema(buyerProfiles);
export const insertManufacturerProfileSchema = createInsertSchema(manufacturerProfiles);
export const insertDistributorProfileSchema = createInsertSchema(distributorProfiles);
export const insertRetailerProfileSchema = createInsertSchema(retailerProfiles);
export const insertVendorProfileSchema = createInsertSchema(vendorProfiles);

export const insertBusinessRelationshipSchema = createInsertSchema(businessRelationships).extend({
  type: z.enum([
    "buyer_manufacturer", 
    "manufacturer_distributor", 
    "distributor_retailer", 
    "manufacturer_retailer", 
    "buyer_vendor", 
    "manufacturer_vendor"
  ]),
  status: z.enum(["pending", "active", "paused", "terminated"]).default("pending")
});

// Create insert schemas for other entities
export const insertPurchaseOrderSchema = createInsertSchema(purchaseOrders);
export const insertVendorSchema = createInsertSchema(vendors);
export const insertInventorySchema = createInsertSchema(inventory);
export const insertInventoryTransactionSchema = createInsertSchema(inventoryTransactions);
export const insertRetailOrderSchema = createInsertSchema(retailOrders);
export const insertPrivacyPolicySchema = createInsertSchema(privacyPolicies);
export const insertDataProcessingPurposeSchema = createInsertSchema(dataProcessingPurposes);
export const insertUserConsentSchema = createInsertSchema(userConsents);
export const insertSampleSchema = createInsertSchema(samples);
export const insertCostSheetSchema = createInsertSchema(costSheets);
export const insertProductionOrderSchema = createInsertSchema(productionOrders);

// Export types
// Organization and user types
export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;

export type BuyerProfile = typeof buyerProfiles.$inferSelect;
export type InsertBuyerProfile = typeof buyerProfiles.$inferInsert;

export type ManufacturerProfile = typeof manufacturerProfiles.$inferSelect;
export type InsertManufacturerProfile = typeof manufacturerProfiles.$inferInsert;

export type DistributorProfile = typeof distributorProfiles.$inferSelect;
export type InsertDistributorProfile = typeof distributorProfiles.$inferInsert;

export type RetailerProfile = typeof retailerProfiles.$inferSelect;
export type InsertRetailerProfile = typeof retailerProfiles.$inferInsert;

export type VendorProfile = typeof vendorProfiles.$inferSelect;
export type InsertVendorProfile = typeof vendorProfiles.$inferInsert;

export type BusinessRelationship = typeof businessRelationships.$inferSelect;
export type InsertBusinessRelationship = z.infer<typeof insertBusinessRelationshipSchema>;

// Update user insertUserSchema to include organization fields
export const extendedInsertUserSchema = insertUserSchema.extend({
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  jobTitle: z.string().optional(),
  organizationId: z.number().optional(),
  department: z.string().optional(),
  accessLevel: z.number().optional().default(1),
});
export type ExtendedInsertUser = z.infer<typeof extendedInsertUserSchema>;

// Original entity types
export type PurchaseOrder = typeof purchaseOrders.$inferSelect;
export type InsertPurchaseOrder = typeof purchaseOrders.$inferInsert;
export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = typeof vendors.$inferInsert;
export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = typeof inventory.$inferInsert;
export type InventoryTransaction = typeof inventoryTransactions.$inferSelect;
export type InsertInventoryTransaction = typeof inventoryTransactions.$inferInsert;
export type RetailOrder = typeof retailOrders.$inferSelect;
export type InsertRetailOrder = typeof retailOrders.$inferInsert;
export type PrivacyPolicy = typeof privacyPolicies.$inferSelect;
export type InsertPrivacyPolicy = typeof privacyPolicies.$inferInsert;
export type DataProcessingPurpose = typeof dataProcessingPurposes.$inferSelect;
export type InsertDataProcessingPurpose = typeof dataProcessingPurposes.$inferInsert;
export type UserConsent = typeof userConsents.$inferSelect;
export type InsertUserConsent = typeof userConsents.$inferInsert;
export type Sample = typeof samples.$inferSelect;
export type InsertSample = typeof samples.$inferInsert;
export type CostSheet = typeof costSheets.$inferSelect;
export type InsertCostSheet = typeof costSheets.$inferInsert;
export type ProductionOrder = typeof productionOrders.$inferSelect;
export type InsertProductionOrder = typeof productionOrders.$inferInsert;